import argparse
import base64
import json
import os
from pathlib import Path
from shutil import copytree
import sys
from time import monotonic
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import cv2
from serial.tools import list_ports

from controller import Controller
from vision import Camera, Classifier, Color, list_cameras, read_image


ROOT = Path(__file__).resolve().parent
BACKGROUND = ROOT / 'background.png'
LOCAL = ROOT / 'settings.local.json'


def load_settings():
    settings = json.loads((ROOT / 'settings.json').read_text(encoding='utf-8'))
    if LOCAL.exists():
        settings.update(json.loads(LOCAL.read_text(encoding='utf-8')))
    return settings


def save_local(update):
    local = json.loads(LOCAL.read_text(encoding='utf-8')) if LOCAL.exists() else {}
    local.update(update)
    temporary = LOCAL.with_suffix('.tmp')
    temporary.write_text(json.dumps(local, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(LOCAL)


def prepare_tk():
    base = Path(sys.base_prefix)
    if os.name != 'nt' or 'WindowsApps' not in base.parts:
        return
    source = base / 'tcl'
    target = Path(sys.prefix) / 'tcl'
    if target != source and (source / 'tcl8.6/init.tcl').is_file():
        if not (target / 'tk8.6/tk.tcl').is_file():
            copytree(source, target, dirs_exist_ok=True)
        os.environ['TCL_LIBRARY'] = (target / 'tcl8.6').as_posix()
        os.environ['TK_LIBRARY'] = (target / 'tk8.6').as_posix()


class SorterApp:
    def __init__(self, root, settings):
        self.root = root
        self.settings = settings
        self.classifier = Classifier(settings)
        self.background = read_image(BACKGROUND) if BACKGROUND.exists() else None
        self.camera = None
        self.stopping_camera = None
        self.file_frame = None
        self.connected = False
        self.running = False
        self.frame_rect = None
        self.drag_start = None
        self.drag_item = None
        self.image = None
        self.shown_key = None
        self.shown_detection = None
        self.closing = False
        self.controller = Controller(settings, self.live_frame)
        self._layout()
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self._tick()

    def _layout(self):
        root = self.root
        root.title('Phân loại phôi  |  Logitech C270 + Xinje XD2')
        root.geometry('1090x710')
        root.minsize(850, 570)
        root.configure(bg='#eef2f5')
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('.', font=('Segoe UI', 10))
        style.configure('TFrame', background='#eef2f5')
        style.configure('TButton', padding=(8, 6))
        style.configure('TLabel', background='#eef2f5', foreground='#162839')
        style.configure('Title.TLabel', font=('Segoe UI Semibold', 20))
        style.configure('Status.TLabel', font=('Segoe UI Semibold', 11), wraplength=270)

        header = ttk.Frame(root, padding=(18, 12))
        header.grid(row=0, column=0, sticky='ew')
        ttk.Label(header, text='Phân loại phôi ba màu', style='Title.TLabel').pack(side='left')
        self.counts = ttk.Label(header, text='Đen 0    Xanh dương 0    Đỏ 0', style='Status.TLabel')
        self.counts.pack(side='right')

        body = ttk.Frame(root, padding=(18, 0, 18, 16))
        body.grid(row=1, column=0, sticky='nsew')
        body.rowconfigure(1, weight=1)
        body.columnconfigure(0, weight=1)
        tools = ttk.Frame(body)
        tools.grid(row=0, column=0, sticky='ew', pady=(0, 8))
        self.camera_button = ttk.Button(tools, text='Mở camera', command=self.toggle_camera)
        self.camera_button.pack(side='left', padx=(0, 6))
        self.file_button = ttk.Button(tools, text='Mở ảnh thử', command=self.open_file)
        self.file_button.pack(side='left', padx=(0, 6))
        self.calibrate_button = ttk.Button(tools, text='Chụp nền trống', command=self.calibrate)
        self.calibrate_button.pack(side='left')

        self.canvas = tk.Canvas(body, bg='#15222f', bd=0, highlightthickness=0)
        self.canvas.grid(row=1, column=0, sticky='nsew')
        self.canvas.bind('<ButtonPress-1>', self.begin_roi)
        self.canvas.bind('<B1-Motion>', self.drag_roi)
        self.canvas.bind('<ButtonRelease-1>', self.end_roi)
        footer = ttk.Frame(body)
        footer.grid(row=2, column=0, sticky='ew', pady=(8, 0))
        self.vision_status = ttk.Label(footer, text='Camera tắt')
        self.vision_status.pack(side='top', anchor='w')
        ttk.Label(footer, text='Kéo chuột trên ảnh camera để chọn ROI trên mặt băng.').pack(side='top', anchor='w')

        side = ttk.Frame(body, padding=(16, 0, 0, 0), width=290)
        side.grid(row=0, column=1, rowspan=3, sticky='ns')
        side.columnconfigure(0, weight=1)
        ttk.Label(side, text='PLC  /  Modbus RTU', style='Status.TLabel').grid(row=0, sticky='w', pady=(3, 8))
        self.ports = {port.device: port.description for port in list_ports.comports()}
        self.port = tk.StringVar(value=self.settings['plc_port'])
        self.port_picker = ttk.Combobox(side, width=27, values=list(self.ports), textvariable=self.port)
        self.port_picker.grid(row=1, sticky='ew', pady=(0, 6))
        self.connect_button = ttk.Button(side, text='Kiểm tra kết nối', command=self.toggle_plc)
        self.connect_button.grid(row=2, sticky='ew', pady=(0, 14))
        self.start_button = ttk.Button(side, text='Chạy băng tải', command=lambda: self.controller.send('start'))
        self.start_button.grid(row=3, sticky='ew', pady=3)
        self.stop_button = ttk.Button(side, text='Dừng băng tải', command=lambda: self.controller.send('stop'))
        self.stop_button.grid(row=4, sticky='ew', pady=3)
        self.reset_button = ttk.Button(side, text='Xoá lỗi PLC', command=lambda: self.controller.send('reset'))
        self.reset_button.grid(row=5, sticky='ew', pady=3)
        self.bench_button = ttk.Button(side, text='Chụp thử một phôi', command=lambda: self.controller.send('bench'))
        self.bench_button.grid(row=6, sticky='ew', pady=3)
        self.plc_status = ttk.Label(side, text='Chưa kết nối PLC', style='Status.TLabel')
        self.plc_status.grid(row=7, sticky='w', pady=(15, 4))
        self.detail = ttk.Label(side, text='', wraplength=265, justify='left')
        self.detail.grid(row=8, sticky='w')
        self.port_description = ttk.Label(side, wraplength=265, justify='left')
        self.port_description.grid(row=9, sticky='w', pady=(5, 0))

    def toggle_camera(self):
        if self.camera is not None:
            self.camera.close()
            self.stopping_camera = self.camera
            self.camera = None
            self.camera_button.configure(text='Mở camera')
            self.vision_status.configure(text='Camera tắt')
            return
        if self.stopping_camera is not None and self.stopping_camera.is_alive():
            self.vision_status.configure(text='Đợi camera giải phóng thiết bị.')
            return
        self.stopping_camera = None
        self.file_frame = None
        self.camera = Camera(self.settings)
        self.camera.start()
        self.shown_key = None
        self.camera_button.configure(text='Tắt camera')
        self.vision_status.configure(text='Đang mở camera…')

    def open_file(self):
        path = filedialog.askopenfilename(
            title='Mở ảnh thử', filetypes=[('Ảnh', '*.png *.jpg *.jpeg *.bmp'), ('Tất cả tệp', '*.*')])
        if not path:
            return
        try:
            frame = read_image(path)
        except (OSError, ValueError) as error:
            self.vision_status.configure(text=str(error))
            return
        if self.camera is not None:
            self.toggle_camera()
        self.file_frame = frame
        self.shown_key = None

    def live_frame(self):
        camera = self.camera
        background = self.background
        sample = camera.latest() if camera is not None and not camera.error else None
        if sample is None or background is None:
            return None
        stamp, frame = sample
        if monotonic() - stamp > 0.55 or frame.shape != background.shape:
            return None
        return stamp, frame, self.classifier, background

    def calibrate(self):
        sample = self.camera.latest() if self.camera is not None else None
        if sample is None or monotonic() - sample[0] > 0.55:
            self.vision_status.configure(text='Cần ảnh camera mới để chụp nền trống.')
            return
        if not messagebox.askokcancel('Chụp nền', 'Đã lấy hết phôi ra khỏi ROI và dừng băng tải?', parent=self.root):
            return
        sample = self.camera.latest() if self.camera is not None else None
        if sample is None or monotonic() - sample[0] > 0.55:
            self.vision_status.configure(text='Camera không có khung hình mới.')
            return
        frame = sample[1]
        valid, data = cv2.imencode('.png', frame)
        if not valid:
            self.vision_status.configure(text='Không ghi được ảnh nền.')
            return
        try:
            temporary = BACKGROUND.with_suffix('.tmp')
            temporary.write_bytes(data.tobytes())
            temporary.replace(BACKGROUND)
        except OSError as error:
            self.vision_status.configure(text=f'Không lưu được ảnh nền. {error}')
            return
        self.background = frame.copy()
        self.shown_key = None

    def begin_roi(self, event):
        if self.running or self.camera is None or self.frame_rect is None:
            return
        self.drag_start = self.canvas_point(event)

    def canvas_point(self, event):
        x, y, w, h = self.frame_rect
        return max(x, min(x + w, event.x)), max(y, min(y + h, event.y))

    def drag_roi(self, event):
        if self.drag_start is None:
            return
        if self.drag_item is not None:
            self.canvas.delete(self.drag_item)
        self.drag_item = self.canvas.create_rectangle(
            *self.drag_start, *self.canvas_point(event), outline='#ffcf54', width=2)

    def end_roi(self, event):
        if self.drag_start is None:
            return
        start, self.drag_start = self.drag_start, None
        if self.drag_item is not None:
            self.canvas.delete(self.drag_item)
            self.drag_item = None
        if self.running or self.camera is None or self.frame_rect is None:
            return
        end = self.canvas_point(event)
        ox, oy, w, h = self.frame_rect
        left, right = sorted((start[0], end[0]))
        top, bottom = sorted((start[1], end[1]))
        if right - left < 25 or bottom - top < 25:
            return
        roi = [(left - ox) / w, (top - oy) / h, (right - ox) / w, (bottom - oy) / h]
        settings = {**self.settings, 'roi': roi}
        try:
            classifier = Classifier(settings)
            save_local({'roi': roi})
        except (OSError, ValueError) as error:
            self.vision_status.configure(text=str(error))
            return
        self.classifier = classifier
        self.settings['roi'] = roi
        self.shown_key = None

    def toggle_plc(self):
        if self.connected:
            self.controller.send('disconnect')
            return
        port = self.port.get().strip().upper()
        if not port:
            self.detail.configure(text='Chọn cổng COM của PLC.')
            return
        self.controller.send('connect', port)

    def _poll_controller(self):
        from queue import Empty
        while True:
            try:
                self.connected, self.running, counts, message = self.controller.events.get_nowait()
            except Empty:
                break
            self.counts.configure(text='    '.join(f'{color.value} {counts[color]}' for color in Color))
            self.detail.configure(text=message)
        state = 'Đang chạy' if self.running else 'Đã xác minh bộ điều khiển' if self.connected else 'Chưa kết nối PLC'
        self.plc_status.configure(text=state)
        self.connect_button.configure(text='Ngắt PLC' if self.connected else 'Kiểm tra kết nối')
        self.port_picker.configure(state='disabled' if self.connected else 'normal')
        self.port_description.configure(text=self.ports.get(self.port.get().upper(), ''))
        self.start_button.configure(state='normal' if self.connected and not self.running and self.live_frame() else 'disabled')
        self.stop_button.configure(state='normal' if self.connected else 'disabled')
        self.reset_button.configure(state='normal' if self.connected and not self.running else 'disabled')
        self.bench_button.configure(state='normal' if self.running else 'disabled')
        self.calibrate_button.configure(state='normal' if self.camera and not self.running else 'disabled')
        self.file_button.configure(state='disabled' if self.running else 'normal')

    def _preview(self):
        sample = self.camera.latest() if self.camera is not None else None
        if self.camera is not None and self.camera.error:
            self.vision_status.configure(text=self.camera.error)
            return
        if sample is None and self.file_frame is None:
            if self.image is not None:
                self.canvas.delete('preview')
                self.image = None
            self.frame_rect = None
            return
        frame = sample[1] if sample else self.file_frame
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        if w < 20 or h < 20 or self.drag_start is not None:
            return
        key = (sample[0] if sample else id(frame), w, h)
        if key == self.shown_key:
            return
        self.shown_key = key
        background = self.background if sample is not None else None
        detection = self.classifier.classify(frame, background)
        suffix = 'Chưa chụp nền' if sample is not None and background is None else detection.reason
        source = self.camera.name if sample is not None else 'Ảnh thử'
        self.vision_status.configure(text=f'{source}  |  {suffix}')
        preview = self.classifier.annotate(frame, detection)
        ih, iw = frame.shape[:2]
        scale = min(w / iw, h / ih)
        pw, ph = max(1, int(iw * scale)), max(1, int(ih * scale))
        x, y = (w - pw) // 2, (h - ph) // 2
        valid, buffer = cv2.imencode('.png', cv2.resize(preview, (pw, ph), interpolation=cv2.INTER_AREA),
                                     [cv2.IMWRITE_PNG_COMPRESSION, 1])
        if valid:
            self.image = tk.PhotoImage(data=base64.b64encode(buffer).decode('ascii'), format='png')
            self.canvas.delete('preview')
            self.canvas.create_image(x, y, image=self.image, anchor='nw', tags='preview')
            self.frame_rect = (x, y, pw, ph)

    def _tick(self):
        if self.closing:
            return
        self._poll_controller()
        self._preview()
        self.root.after(115, self._tick)

    def close(self):
        self.closing = True
        self.controller.send('close')
        self.controller.thread.join(timeout=1.5)
        for camera in (self.camera, self.stopping_camera):
            if camera is not None:
                camera.close()
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description='Phân loại ba màu bằng Logitech C270 và PLC Xinje XD2')
    parser.add_argument('--list-devices', action='store_true', help='Liệt kê camera và cổng COM')
    parser.add_argument('--image', type=Path, help='Kiểm tra một ảnh offline')
    parser.add_argument('--background', type=Path, help='Ảnh nền cùng kích thước cho chế độ offline')
    parser.add_argument('--smoke-ui', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.list_devices:
        for device in list_cameras():
            print(f'Camera {device.index}: {device.name}')
        for port in list_ports.comports():
            print(f'{port.device}: {port.description}')
        return
    settings = load_settings()
    if args.image:
        background = read_image(args.background) if args.background else None
        detection = Classifier(settings).classify(read_image(args.image), background)
        print(detection.reason)
        for x, y, w, h, color in detection.boxes:
            print(color.name if color is not None else 'UNKNOWN', x, y, w, h)
        return
    prepare_tk()
    root = tk.Tk()
    app = SorterApp(root, settings)
    if args.smoke_ui:
        root.withdraw()
        root.after(250, app.close)
    root.mainloop()


if __name__ == '__main__':
    main()
