import argparse
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
from queue import Empty
from secrets import compare_digest, token_urlsafe
from threading import RLock
from time import monotonic, perf_counter
import webbrowser

os.environ.setdefault('OPENCV_IO_MAX_IMAGE_PIXELS', '20000000')
import cv2
import numpy as np
from serial.tools import list_ports

from belt_vision import BeltVision
from controller import Controller
from plc import OUTPUTS, Plc
from vision import Classifier, Color, read_image


ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / 'web'
SAMPLES = ('black', 'blue', 'red')
FILES = {'/', '/index.html', '/app.js', '/styles.css', '/assets/belt.jpg',
         *(f'/assets/{name}.jpg' for name in SAMPLES)}
FRAME_TTL = 0.52


def read_settings():
    values = json.loads((ROOT / 'settings.json').read_text(encoding='utf-8'))
    local = ROOT / 'settings.local.json'
    if local.is_file():
        values.update(json.loads(local.read_text(encoding='utf-8')))
    return values


def decode(data):
    try:
        frame = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    except cv2.error as error:
        raise ValueError('Ảnh quá lớn hoặc định dạng không hợp lệ.') from error
    if frame is None or min(frame.shape[:2]) < 32:
        raise ValueError('Cần ảnh hợp lệ, kích thước tối thiểu 32 × 32.')
    return frame


class Dashboard:
    def __init__(self, settings):
        self.settings = settings
        self.classifier = Classifier(settings)
        self.sample_classifier = Classifier({**settings, 'roi': [0.10, 0.16, 0.90, 0.86]})
        self.vision = BeltVision(settings)
        self.mutex = RLock()
        self.camera = None
        self.camera_id = None
        self.camera_since = 0.0
        self.frame = None
        self.analyzed_scene = None
        self.pending = False
        self.connected = self.running = False
        self.port = settings['plc_port']
        self.output_snapshot = None
        self.counts = {color.name.lower(): 0 for color in Color}
        self.log = deque(maxlen=30)
        self.controller = Controller(settings, self.live_frame, legacy_frame_source=self.live_belt_frame)
        self.event('Hệ thống', 'Dashboard sẵn sàng. Mở camera để nhận diện.')

    def event(self, source, message):
        self.log.appendleft({'time': datetime.now().strftime('%H:%M:%S'),
                             'source': source, 'message': message})

    def _read_controller(self):
        while True:
            try:
                connected, running, counts, message = self.controller.events.get_nowait()
            except Empty:
                return
            self.connected, self.running = connected, running
            self.pending = False
            if self.controller.profile == 'offline':
                self.output_snapshot = None
            self.counts = {color.name.lower(): counts[color] for color in Color}
            self.event('PLC', message)

    def _fresh(self):
        return self.frame is not None and monotonic() - self.frame[0] <= FRAME_TTL

    def live_frame(self):
        with self.mutex:
            if not self._fresh():
                return None
            stamp, result = self.frame
            return (stamp, result.at_station) if result.ready else None

    def live_belt_frame(self):
        with self.mutex:
            if not self._fresh():
                return None
            stamp, result = self.frame
            return stamp, result.detection if result.ready else None

    def state(self):
        with self.mutex:
            self._read_controller()
            signals = self.controller.signal_snapshot
            if signals and monotonic() - signals['stamp'] > 1.5:
                signals = None
            return {
                'camera': self.camera if self._fresh() else None,
                'calibrated': self.live_frame() is not None,
                'beltStatus': self.frame[1].status if self._fresh() else 'offline',
                'connected': self.connected,
                'running': self.running,
                'pending': self.pending,
                'port': self.port,
                'outputs': self.output_snapshot,
                'profile': self.controller.profile,
                'signals': signals,
                'manualSupported': self.controller.manual_supported,
                'manualHoldRelays': self.controller.manual_hold_relays,
                'manualTarget': self.controller.manual_target,
                'baud': self.settings['plc_baud'],
                'parity': self.settings['plc_parity'],
                'stopBits': self.settings['plc_stop_bits'],
                'station': self.settings['plc_station'],
                'ports': [port.device for port in list_ports.comports()],
                'counts': self.counts.copy(),
                'events': list(self.log),
            }

    def open_camera(self, name):
        if not isinstance(name, str) or not name.strip() or len(name) > 120:
            raise ValueError('Chọn một camera hợp lệ.')
        with self.mutex:
            self._read_controller()
            if self.running or self.pending:
                raise ValueError('Dừng PLC trước khi đổi camera.')
            if self._fresh() or (self.camera_id and monotonic() - self.camera_since < 1.0):
                raise ValueError('Camera đang truyền từ một tab khác.')
            self.camera_id = token_urlsafe(16)
            self.camera_since = monotonic()
            self.camera = name
            self.frame = None
            self.analyzed_scene = None
            self.vision.reset()
            self.event('Camera', f'Đã chọn {name}.')
            return self.camera_id

    def _check_camera(self, key):
        if self.camera_id is None or not compare_digest(key, self.camera_id):
            raise ValueError('Phiên camera đã kết thúc. Mở lại camera.')

    def close_camera(self, key):
        with self.mutex:
            if key and self.camera_id == key:
                self.camera_id = self.camera = self.frame = None
                self.analyzed_scene = None
                self.vision.reset()
                self.event('Camera', 'Đã tắt camera.')

    def frame_from_camera(self, key, frame):
        with self.mutex:
            self._check_camera(key)
            begin = perf_counter()
            scene = None
            if not (self.pending or self.controller.running or self.controller.manual_target is not None):
                scene = cv2.resize(frame, (160, 90), interpolation=cv2.INTER_AREA)
            reused = bool(scene is not None and self.analyzed_scene is not None and self._fresh()
                          and self.vision.shape == frame.shape
                          and np.count_nonzero(cv2.absdiff(scene, self.analyzed_scene).max(axis=2) > 9) < 12)
            if reused:
                result = self.frame[1]
            else:
                result = self.vision.update(frame)
                # Compare against the last analyzed scene so small shifts can accumulate.
                self.analyzed_scene = scene if result.ready else None
            self.frame = (monotonic(), result)
        height, width = frame.shape[:2]
        detection = result.detection
        boxes = detection.boxes
        return {
            'color': detection.color.name.lower() if detection.color else None,
            'reason': detection.reason,
            'latency': None if reused else round((perf_counter() - begin) * 1000, 1),
            'reused': reused,
            'belt': [[x / width, y / height] for x, y in result.outline],
            'beltStatus': result.status,
            'objectCount': len(detection.boxes) if result.ready else None,
            'boxes': [[x / width, y / height, w / width, h / height,
                       color.name.lower() if color else None] for x, y, w, h, color in boxes],
        }

    def offline(self, frame, sample=False):
        with self.mutex:
            classifier = self.sample_classifier if sample else self.classifier
        result = self.classify(frame, classifier, None)
        with self.mutex:
            self.event('Ảnh thử', result['reason'])
        return result

    @staticmethod
    def classify(frame, classifier, background):
        begin = perf_counter()
        result = classifier.classify(frame, background)
        height, width = frame.shape[:2]
        return {
            'color': result.color.name.lower() if result.color else None,
            'reason': result.reason,
            'latency': round((perf_counter() - begin) * 1000, 1),
            'roi': classifier.roi,
            'boxes': [[x / width, y / height, w / width, h / height,
                       color.name.lower() if color else None] for x, y, w, h, color in result.boxes],
        }

    def command(self, action, argument, data=None):
        if action == 'connect':
            return self.probe(argument)
        with self.mutex:
            self._read_controller()
            profile = self.controller.profile
            if action == 'manual-ping':
                if self.controller.manual_target is not None:
                    self.controller.send('manual-ping')
                return
            if action == 'legacy':
                if self.pending or profile != 'monitor' or (data or {}).get('confirmed') is not True:
                    raise ValueError('Cần xác nhận ánh xạ Y0, Y1 và Y2 trước khi bật điều khiển.')
            elif action in {'manual-on', 'manual-off'}:
                argument = (data or {}).get('channel')
                if type(argument) is not int or argument not in (0, 1, 2):
                    raise ValueError('Chọn ngõ ra Y0, Y1 hoặc Y2.')
                if self.pending or self.running or not self.controller.manual_supported:
                    raise ValueError('Dừng phân loại và xác nhận ngõ ra trước khi điều khiển tay.')
                if action == 'manual-on' and argument != 0 and not self.controller.manual_hold_relays:
                    raise ValueError('Cần cập nhật chương trình PLC để giữ Y1 hoặc Y2.')
            elif action == 'disconnect':
                if profile == 'offline' or self.pending:
                    raise ValueError('PLC không có phiên để ngắt.')
            elif action == 'stop':
                if not self.connected:
                    raise ValueError('PLC chưa được xác minh.')
            elif action == 'start':
                if profile not in {'auto', 'legacy'} or self.pending:
                    raise ValueError('Kết nối và xác nhận ngõ ra PLC trước khi chạy.')
                if self.running or self.controller.manual_target is not None or self.live_frame() is None:
                    raise ValueError('Dừng chế độ tay và đợi camera tự xác định mặt băng.')
            elif action not in {'reset', 'bench'} or profile != 'auto' or self.pending:
                raise ValueError('PLC chưa sẵn sàng cho thao tác này.')
            elif action == 'reset' and self.running:
                raise ValueError('Dừng băng tải trước khi xoá lỗi.')
            elif action == 'bench' and not self.running:
                raise ValueError('Cần băng tải đang chạy để gửi yêu cầu chụp.')
            self.pending = True
            self.controller.send(action, argument)

    def probe(self, port):
        with self.mutex:
            self._read_controller()
            devices = {item.device: item.description for item in list_ports.comports()}
            if port not in devices or self.controller.profile != 'offline' or self.pending:
                raise ValueError('Chọn cổng COM đang hiện trong Windows và ngắt phiên PLC cũ trước.')
            self.port = port
            self.output_snapshot = None
            if 'active management technology' in devices[port].lower():
                message = f'Windows nhận {port} là Intel SOL. Chọn cổng của adapter USB–RS232 Xinje.'
                self.event('PLC', message)
                raise ValueError(message)
            self.pending = True
        try:
            plc = Plc.open_link(port, self.settings)
            try:
                try:
                    plc.status()
                    compatible = True
                except ValueError:
                    compatible = False
                outputs = plc.read_coils(OUTPUTS, 3)
            except BaseException:
                plc.close()
                raise
        except (OSError, ValueError) as error:
            with self.mutex:
                self.pending = False
                self.event('PLC', str(error))
            raise ValueError(f'{port}: {error}') from error
        with self.mutex:
            self.output_snapshot = {
                'values': outputs,
                'compatible': compatible,
                'time': datetime.now().strftime('%H:%M:%S'),
            }
            self.controller.send('adopt', (plc, compatible))

    def close(self):
        self.controller.send('close')
        self.controller.thread.join(timeout=2)


class DashboardServer(ThreadingHTTPServer):
    def __init__(self, port, settings):
        super().__init__(('127.0.0.1', port), Request)
        self.dashboard = Dashboard(settings)
        self.token = token_urlsafe(24)


class Request(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *_args):
        pass

    def reply(self, value, status=200):
        self.send_content(json.dumps(value, ensure_ascii=False).encode(), 'application/json; charset=utf-8', status)

    def send_content(self, data, content_type, status=200):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' blob:; "
                         "media-src 'self' blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
        self.send_header('Permissions-Policy', 'camera=(self), microphone=()')
        self.end_headers()
        self.wfile.write(data)

    def local_host(self):
        port = self.server.server_port
        return self.headers.get('Host') in {f'127.0.0.1:{port}', f'localhost:{port}'}

    def do_GET(self):
        if not self.local_host():
            return self.reply({'error': 'Mở dashboard từ địa chỉ cục bộ.'}, 403)
        if self.path == '/api/state':
            return self.reply({**self.server.dashboard.state(), 'token': self.server.token})
        if self.path not in FILES:
            return self.reply({'error': 'Không tìm thấy.'}, 404)
        path = PUBLIC / ('index.html' if self.path == '/' else self.path.lstrip('/'))
        self.send_content(path.read_bytes(), mimetypes.guess_type(path)[0] or 'application/octet-stream')

    def body(self, limit):
        length = int(self.headers.get('Content-Length', '0'))
        if not (0 <= length <= limit):
            raise ValueError('Dữ liệu vượt kích thước cho phép.')
        data = self.rfile.read(length)
        if len(data) != length:
            raise ValueError('Dữ liệu ảnh chưa tải xong.')
        return data

    def do_POST(self):
        origin = self.headers.get('Origin')
        token = self.headers.get('X-Sorter-Token', '')
        if not self.local_host() or not compare_digest(token, self.server.token) or (
            origin and origin != 'http://' + self.headers['Host']
        ):
            return self.reply({'error': 'Phiên dashboard không hợp lệ.'}, 403)
        service = self.server.dashboard
        camera_key = self.headers.get('X-Sorter-Camera', '')
        try:
            if self.path == '/api/frame':
                return self.reply(service.frame_from_camera(camera_key, decode(self.body(2 * 1024 * 1024))))
            if self.path == '/api/image':
                return self.reply(service.offline(decode(self.body(10 * 1024 * 1024))))
            data = json.loads(self.body(4096) or b'{}')
            if not isinstance(data, dict):
                raise ValueError('Yêu cầu không hợp lệ.')
            if self.path == '/api/sample' and data.get('name') in SAMPLES:
                return self.reply(service.offline(read_image(PUBLIC / 'assets' / (data['name'] + '.jpg')), sample=True))
            if self.path == '/api/camera/open':
                return self.reply({'cameraId': service.open_camera(data.get('name'))})
            if self.path == '/api/camera/close':
                service.close_camera(camera_key)
                return self.reply({'ok': True})
            if self.path == '/api/plc':
                service.command(data.get('action'), data.get('port'), data)
                return self.reply({'ok': True})
            return self.reply({'error': 'Không tìm thấy thao tác.'}, 404)
        except (ValueError, TypeError) as error:
            return self.reply({'error': str(error)}, 400)


def main():
    parser = argparse.ArgumentParser(description='Dashboard ThreeColorSorter')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--serve-only', action='store_true')
    args = parser.parse_args()
    with DashboardServer(args.port, read_settings()) as server:
        url = f'http://127.0.0.1:{server.server_port}/'
        print(f'ThreeColorSorter: {url}', flush=True)
        if not args.serve_only:
            webbrowser.open(url)
        try:
            server.serve_forever(poll_interval=0.2)
        except KeyboardInterrupt:
            pass
        finally:
            server.dashboard.close()


if __name__ == '__main__':
    main()
