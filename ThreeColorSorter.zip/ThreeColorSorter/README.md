# ThreeColorSorter

ThreeColorSorter nhận diện phôi **đen, xanh dương và đỏ** trên băng tải màu đen. Dashboard hiển thị video, viền mặt băng, khung phôi và số đếm. Kết nối Modbus RTU với PLC Xinje XD2 cho phép đọc tín hiệu và điều khiển băng tải cùng hai đèn phân loại.

## Chạy trên Windows

Clone repo, mở PowerShell trong thư mục vừa clone và chạy các lệnh sau. Cần Python 3.12 x64 và Chrome hoặc Edge.

```powershell
py -3.12 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\Run.cmd
```

Dashboard mở tại `http://127.0.0.1:8765/`. Trang ưu tiên mở Logitech C270 nếu trình duyệt đã cấp quyền camera. Có thể xem nhận diện trực tiếp khi PLC chưa kết nối. Nếu máy dùng webcam khác, bấm **Mở camera** rồi chọn thiết bị.

## Nhận diện phôi

Trình duyệt lấy khung hình từ USB video và gửi ảnh đến máy chủ Python trên cùng máy. OpenCV xác định mặt băng trước khi tìm phôi.

- **Góc thấp.** Xác định hai mép băng, tạo mặt nạ HSV rồi kiểm tra chân phôi nằm trên mặt băng. Bước kiểm chân giúp tách phôi đen khỏi nền tối.
- **Góc cao.** Nắn phối cảnh mặt băng, so nền theo LAB rồi tính tỷ lệ màu HSV trên từng vùng phôi.
- **Theo thời gian.** Trong chế độ PLC tham chiếu, bộ đếm tăng khi xác nhận phôi qua ba khung hợp lệ. Phôi còn trong khung được theo dõi để tránh đếm lặp. Khi video vẫn về và thuật toán tạm mất dấu mặt băng, băng tải tiếp tục chạy trong lúc tìm lại mép.

## Kết nối PLC

Nối máy tính với PLC qua adapter USB–RS232. Trong dashboard, chọn COM Windows của adapter và bấm **Kết nối**. Cấu hình mặc định là Modbus RTU `19200`, `8E1`, station `1`. Số cổng thực xem trong Windows hoặc chạy `Run.cmd --list-devices`. Có thể ghi đè cấu hình qua `settings.local.json`.

| Ngõ ra | Tín hiệu |
| --- | --- |
| Y0 | Băng tải |
| Y1 | Đèn phôi đen |
| Y2 | Đèn phôi xanh dương |

Sau khi đã xác nhận ánh xạ và camera nhận diện được mặt băng, bấm **Start phân loại**. Với chương trình PLC tham chiếu, đèn giữ khi còn thấy phôi tương ứng. Phôi đỏ đi thẳng. **Stop tất cả** dừng lượt chạy. Dùng các nút **Bật/Tắt** ở từng hàng để thử một ngõ ra khi hệ thống đang dừng.

Nếu PLC dùng tiếp điểm tự giữ, web gửi tắt coil màu rồi đọc lại ngõ ra. Web chỉ dùng M1 để nhả ngõ nếu đã xác nhận băng trống. Tệp PLC tùy chọn dùng cảm biến X0 có chu trình riêng. Xem [ánh xạ, giao thức và nguồn PLC](plc/README.md) trước khi nạp hoặc vận hành thiết bị.

## Cấu trúc mã

| Tệp | Vai trò |
| --- | --- |
| `vision.py`, `belt_vision.py` | Tìm mặt băng, tách phôi, gán màu |
| `web_app.py`, `web/` | Máy chủ cục bộ, luồng ảnh, dashboard |
| `controller.py`, `plc.py` | Theo dõi phôi, điều phối ngõ ra, truyền Modbus RTU |
| `plc/` | Tài liệu I/O và nguồn Instruction List cho chương trình tùy chọn |
| `tests/` | Kiểm ảnh, web, giao thức và PLC mô phỏng |

## Kiểm thử

```powershell
& .\.venv\Scripts\python.exe -X utf8 -B -m unittest discover -s tests -v
```

Các ảnh trong `web/assets/` là ảnh dựng để chạy kiểm thử. Có thể kiểm toàn bộ bộ test khi chưa cắm camera hoặc PLC. Xem [kịch bản kiểm](KIEM_THU.md) để đối chiếu kết quả mô phỏng và những phần cần xác nhận tại máy.

Dự án tham khảo sơ đồ và cấu hình ban đầu từ [BTL_Computer_Vision](https://github.com/Thinhngua1/BTL_Computer_Vision). Phần xử lý ảnh dùng phương pháp phân vùng vật thể theo ME6604, Chương 3, mục 3.3.
