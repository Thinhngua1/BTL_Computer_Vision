@echo off
setlocal
if not exist "%~dp0.venv\Scripts\python.exe" (
    echo Python environment not found. See README.md for setup.
    if "%~1"=="" pause
    exit /b 1
)
if "%~1"=="--desktop" (
    "%~dp0.venv\Scripts\python.exe" -X utf8 -B "%~dp0app.py"
) else if "%~1"=="--list-devices" (
    "%~dp0.venv\Scripts\python.exe" -X utf8 -B "%~dp0app.py" %*
) else if "%~1"=="--image" (
    "%~dp0.venv\Scripts\python.exe" -X utf8 -B "%~dp0app.py" %*
) else if "%~1"=="--smoke-ui" (
    "%~dp0.venv\Scripts\python.exe" -X utf8 -B "%~dp0app.py" %*
) else (
    "%~dp0.venv\Scripts\python.exe" -X utf8 -B "%~dp0web_app.py" %*
)
if errorlevel 1 (
    if "%~1"=="" pause
    exit /b 1
)
