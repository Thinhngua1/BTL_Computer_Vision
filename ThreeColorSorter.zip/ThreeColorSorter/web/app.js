'use strict';

const byId = (id) => document.getElementById(id);
const video = byId('video');
const overlay = byId('overlay');
const screen = byId('screen');
const cameraPicker = byId('camera-device');
const port = byId('port');
const legacyDialog = byId('legacy-dialog');
const labels = {
  black: ['Đen', 'Đèn tín hiệu · Y1', '#b8c9da'],
  blue: ['Xanh dương', 'Đèn tín hiệu · Y2', '#79a7ff'],
  red: ['Đỏ', 'Đi thẳng', '#ff8993'],
};
const encoder = document.createElement('canvas');
const enc = encoder.getContext('2d', {alpha: false});
const ctx = overlay.getContext('2d');

let board = null;
let stream = null;
let cameraKey = '';
let cameraBusy = false;
let autoCameraPending = true;
let frameTimer = 0;
let lastVideoTime = -1;
let lastDetection = null;
let mode = 'idle';
let startIntent = 0;
let openingForStart = false;
let confirmStarts = false;
let toastTimer = 0;
let pollBusy = false;
let lastEventKey = '';

function setText(target, value) {
  const el = typeof target === 'string' ? byId(target) : target;
  if (el.textContent !== value) el.textContent = value;
}

function chip(id, value, active, running = false) {
  const el = byId(id);
  el.classList.toggle('live', active);
  el.classList.toggle('running', running);
  if (el.lastChild.nodeType !== Node.TEXT_NODE) el.append(document.createTextNode(''));
  if (el.lastChild.nodeValue !== value) el.lastChild.nodeValue = value;
}

function toast(message, isError = false) {
  const box = byId('toast');
  box.classList.toggle('error', isError);
  box.textContent = message;
  box.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { box.hidden = true; }, 5200);
}

async function request(path, body, signal) {
  const headers = {};
  const options = {signal, cache: 'no-store'};
  if (body !== undefined) {
    options.method = 'POST';
    headers['X-Sorter-Token'] = board?.token || '';
    headers['X-Sorter-Camera'] = cameraKey;
    if (body instanceof Blob) {
      headers['Content-Type'] = body.type || 'application/octet-stream';
      options.body = body;
    } else {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
  }
  options.headers = headers;
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Dashboard chưa phản hồi.');
  return data;
}

function showMode(value, title) {
  mode = value;
  const live = value === 'camera';
  video.hidden = !live;
  byId('calibration').hidden = !live;
  byId('camera-hint').textContent = live ? 'USB video' : 'Logitech C270 · USB video';
  byId('screen-footer').firstElementChild.textContent = title;
  byId('dimensions').textContent = '';
  setText('vision-source', title);
  chip('view-tag', live ? ' TRỰC TIẾP' : ' CHỜ CAMERA', live);
  chip('mode', live ? ' Camera trực tiếp' : ' Chờ camera', live);
}

function showDetection(result) {
  if (result?.reused && lastDetection?.reused) return;
  lastDetection = result;
  const color = result?.color && labels[result.color];
  byId('result-dot').className = 'result-dot' + (color ? ' ' + result.color : '');
  const count = result?.objectCount;
  const countText = count == null ? '' : count + ' phôi trên băng';
  setText('result-label', color?.[0] || countText ||
    (mode === 'camera' ? 'Đang xác định mặt băng' : 'Chờ nhận diện'));
  setText('result-sub', color ? countText : result?.reason || 'Chờ khung hình từ camera');
  setText('route', color ? color[1] : '—');
  setText('latency', result?.reused ? 'Giữ kết quả' :
    result?.latency != null ? result.latency.toLocaleString('vi-VN') + ' ms' : '—');
  if (mode === 'camera') {
    setText(byId('screen-footer').firstElementChild,
      color ? color[0] + ' · ' + color[1] :
        countText || result?.reason || 'Đang mở camera');
  }
  draw();
}

function frameRect() {
  if (mode === 'idle') return null;
  const width = video.videoWidth;
  const height = video.videoHeight;
  if (!width || !height) return null;
  const area = overlay.getBoundingClientRect();
  const scale = Math.min(area.width / width, area.height / height);
  const w = width * scale;
  const h = height * scale;
  return {area, left: (area.width - w) / 2, top: (area.height - h) / 2, w, h};
}

function draw() {
  const area = overlay.getBoundingClientRect();
  const density = window.devicePixelRatio || 1;
  const width = Math.round(area.width * density), height = Math.round(area.height * density);
  if (overlay.width !== width || overlay.height !== height) {
    overlay.width = width;
    overlay.height = height;
  }
  ctx.setTransform(density, 0, 0, density, 0, 0);
  ctx.clearRect(0, 0, area.width, area.height);
  const rect = frameRect();
  if (!rect) return;
  const point = (x, y) => [rect.left + x * rect.w, rect.top + y * rect.h];
  if (lastDetection?.belt?.length === 4) {
    const [first, ...remaining] = lastDetection.belt;
    ctx.beginPath();
    ctx.moveTo(...point(...first));
    for (const corner of remaining) ctx.lineTo(...point(...corner));
    ctx.closePath();
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = '#65e6c9';
    ctx.fillStyle = '#65e6c916';
    ctx.fill();
    ctx.stroke();
  }
  for (const [x, y, w, h, color] of lastDetection?.boxes || []) {
    const [left, top] = point(x, y);
    const label = color ? labels[color][0] : 'Không rõ';
    const tone = color ? labels[color][2] : '#ffc980';
    ctx.strokeStyle = tone;
    ctx.lineWidth = 2;
    ctx.strokeRect(left, top, w * rect.w, h * rect.h);
    ctx.font = '600 13px Segoe UI';
    ctx.textBaseline = 'middle';
    const tagWidth = ctx.measureText(label).width + 14;
    const tagTop = top - rect.top >= 23 ? top - 22 : top;
    const tagLeft = Math.max(rect.left, Math.min(left, rect.left + rect.w - tagWidth));
    ctx.fillStyle = '#121c28';
    ctx.fillRect(tagLeft, tagTop, tagWidth, 21);
    ctx.fillStyle = tone;
    ctx.fillText(label, tagLeft + 7, tagTop + 10);
  }
}

function renderState() {
  if (!board) return;
  const cameraOn = Boolean(stream && board.camera);
  const latestPlc = board.events.find((item) => item.source === 'PLC');
  const plcAnswered = board.profile === 'monitor';
  const portOpened = board.profile !== 'offline';
  chip('camera-status', cameraOn ? 'Camera trực tiếp' : stream ? 'Đang nhận ảnh' : 'Camera tắt', cameraOn);
  const beltOn = board.signals?.outputs[0] === true;
  chip('plc-status', beltOn ? 'PLC xác nhận Y0 bật' : board.running ? 'Đang phân loại' : board.connected ? 'PLC đã kết nối' :
    plcAnswered ? 'Modbus có phản hồi' : 'PLC chưa kết nối',
    board.connected, beltOn);
  byId('plc-status').classList.toggle('warning', Boolean(plcAnswered));
  const selection = port.value || board.port;
  const names = [...new Set([board.port, ...board.ports])];
  if ([...port.options].map((opt) => opt.value).join() !== names.join()) {
    port.replaceChildren(...names.map((item) => new Option(item, item)));
  }
  port.value = portOpened ? board.port : names.includes(selection) ? selection : board.port;
  port.disabled = board.pending || portOpened;
  setText(byId('connect').lastElementChild, board.pending && !board.connected ? 'Đang đọc' :
    portOpened ? 'Ngắt PLC' : 'Kết nối');
  byId('connect').disabled = board.pending;
  byId('start').disabled = !portOpened || !board.signals || board.running || board.pending ||
    board.manualTarget !== null || openingForStart || board.signals.outputs.some(Boolean);
  setText(byId('start').lastElementChild, openingForStart ? 'Đang kiểm tra camera' :
    board.running ? 'Đang phân loại' : 'Start phân loại');
  byId('stop').disabled = !board.connected && !openingForStart;
  byId('trigger').hidden = byId('reset').hidden = board.profile !== 'auto';
  byId('trigger').disabled = !board.running || board.pending;
  byId('reset').disabled = board.profile !== 'auto' || board.running || board.pending || board.manualTarget !== null;
  cameraPicker.disabled = board.running || cameraBusy;
  if (stream) setText('camera-hint', board.calibrated ? 'Đã tự khoanh mặt băng' :
    board.beltStatus === 'lost' ? 'Mất dấu băng tải' : 'Đang tự tìm mặt băng');
  const link = 'Modbus RTU · ' + board.baud + ' · 8' + board.parity + board.stopBits + ' · ID ' + board.station;
  setText('serial-info', link);
  setText('plc-note', latestPlc?.message || 'Kết nối Modbus trước khi chạy.');
  const outputFault = latestPlc?.message.startsWith('Đã dừng. Y');
  const relayNote = board.profile === 'legacy' && board.camera && !board.calibrated ?
    'Băng tải vẫn chạy. Đang tìm lại mặt băng.' :
    board.signals?.outputs[1] ? 'PLC xác nhận đèn Y1 sáng cho phôi đen.' :
    board.signals?.outputs[2] ? 'PLC xác nhận đèn Y2 sáng cho phôi xanh dương.' :
    'PLC xác nhận Y0 bật. Đang theo dõi toàn mặt băng.';
  const note = board.running ? (beltOn ? relayNote :
    board.signals ? 'Đang phân loại. PLC đọc Y0 tắt.' : 'Đang chờ đọc ngõ ra PLC.') :
    openingForStart ? 'Đang tự xác định mặt băng trước khi chạy.' :
    board.manualTarget !== null ? 'Đang điều khiển tay Y' + board.manualTarget + '. Tắt ngõ ra trước khi Start.' :
    outputFault ? latestPlc.message :
    board.profile === 'monitor' ? 'Đã đọc được PLC. Xác nhận đấu Y0–Y2 một lần để điều khiển.' :
    board.profile === 'offline' ? 'Kết nối PLC để chạy phân loại.' :
    board.calibrated ? 'Sẵn sàng phân loại theo màu.' : 'Start sẽ mở camera và tự tìm mặt băng.';
  setText('control-note', note);
  byId('output-read').hidden = !board.outputs || board.running || Boolean(board.signals);
  if (board.outputs) {
    setText('output-time', board.outputs.time);
    board.outputs.values.forEach((on, index) => {
      const output = byId('out-' + index);
      output.classList.toggle('on', on);
      setText(output, 'Y' + index + ' · ' + (on ? 'Bật' : 'Tắt'));
    });
  }
  renderSignals();
  for (const color of Object.keys(labels)) setText('count-' + color, String(board.counts[color]));
  setText('total', String(Object.values(board.counts).reduce((sum, number) => sum + number, 0)));
  const eventKey = JSON.stringify(board.events);
  if (eventKey !== lastEventKey) {
    lastEventKey = eventKey;
    byId('events').replaceChildren(...board.events.map((entry) => {
      const row = document.createElement('li');
      for (const [tag, value] of [['time', entry.time], ['small', entry.source], ['div', entry.message]]) {
        const node = document.createElement(tag);
        node.textContent = value;
        row.append(node);
      }
      return row;
    }));
  }
}

function renderSignals() {
  const signals = board.signals;
  const manualReady = board.manualSupported && !board.pending && !board.running && !openingForStart;
  const canTurnOn = manualReady && signals && board.manualTarget === null && !signals.outputs.some(Boolean);
  const manualNote = board.manualTarget !== null ? 'Đang giữ Y' + board.manualTarget + '. Chọn Tắt hoặc Stop tất cả để nhả.' :
    board.running || openingForStart ? 'Dừng phân loại trước khi điều khiển tay.' :
    board.manualSupported && !board.manualHoldRelays ? 'PLC hiện hỗ trợ giữ Y0. Cập nhật chương trình PLC để giữ Y1 và Y2.' :
    board.manualSupported ? 'Chọn một ngõ ra để bật. Giữ phiên điều khiển mở trong lúc kiểm tra.' :
    'Kết nối và xác nhận ngõ ra trên PLC để điều khiển tay.';
  setText('manual-note', manualNote);
  chip('signal-status', signals ? 'Đang đọc ' + board.port : 'Chưa có tín hiệu', Boolean(signals));
  const lists = [
    ['inputs', ['X0', 'X1', 'X2', 'X3'].map((name, index) => [name, signals?.inputs[index]])],
    ['command-bits', ['M0', 'M1', 'M10', 'M11', 'M12', 'M13'].map((name) => [name, signals?.commands[name]])],
  ];
  for (const [id, bits] of lists) {
    const markup = bits.map(([name, on]) => {
      const item = document.createElement('li');
      item.classList.toggle('on', on === true);
      item.textContent = name + ' · ' + (on == null ? '—' : on ? '1' : '0');
      return item;
    });
    byId(id).replaceChildren(...markup);
  }
  [0, 1, 2].forEach((channel) => {
    const on = signals?.outputs[channel];
    const el = byId('relay-state-' + channel);
    el.classList.toggle('on', on === true);
    setText(el, on == null ? '—' : on ? 'Bật' : 'Tắt');
  });
  document.querySelectorAll('.relay-control').forEach((button) => {
    const channel = Number(button.dataset.channel);
    button.disabled = button.dataset.action === 'manual-on'
      ? !canTurnOn || (channel !== 0 && !board.manualHoldRelays)
      : !manualReady || board.manualTarget !== channel;
  });
  byId('legacy-button').hidden = board.profile !== 'monitor';
  byId('legacy-button').disabled = board.pending || !signals;
}
async function refresh() {
  if (pollBusy) return;
  pollBusy = true;
  try {
    board = await request('/api/state');
    renderState();
    if (autoCameraPending && document.visibilityState === 'visible') {
      if (board.camera && !stream) showMode('idle', 'Camera đang mở ở tab khác');
      else if (!board.running && !board.pending) handled(cameraAction(undefined, true));
    }
  } catch {
    chip('plc-status', 'Mất kết nối máy chủ', false);
    byId('start').disabled = byId('connect').disabled = true;
  } finally {
    pollBusy = false;
  }
}

function stopTracks(media) {
  media?.getTracks().forEach((track) => track.stop());
}

function messageFor(error) {
  if (error.name === 'NotAllowedError') return 'Trình duyệt chưa cấp quyền camera. Cho phép camera ở biểu tượng cạnh thanh địa chỉ.';
  if (error.name === 'NotReadableError') return 'Không mở được camera. Kiểm tra Windows Camera hoặc ứng dụng khác đang dùng thiết bị.';
  if (error.name === 'NotFoundError') return 'Không tìm thấy thiết bị video. Kiểm tra dây Logitech C270.';
  return error.message;
}

async function stopCamera() {
  const oldKey = cameraKey;
  clearTimeout(frameTimer);
  stopTracks(stream);
  stream = null;
  video.srcObject = null;
  if (mode === 'camera') {
    showMode('idle', 'Camera tắt');
    showDetection(null);
  }
  chip('camera-status', 'Camera tắt', false);
  setText(byId('camera-button').lastElementChild, 'Mở camera');
  if (oldKey) {
    try { await request('/api/camera/close', {}); }
    finally { cameraKey = ''; await refresh(); }
  }
}

async function startCamera(deviceId, automatic) {
  const media = navigator.mediaDevices;
  if (!media?.getUserMedia) throw new Error('Mở dashboard bằng Chrome hoặc Edge từ địa chỉ cục bộ.');
  if (!board) await refresh();
  if (!board) throw new Error('Máy chủ xử lý ảnh chưa sẵn sàng.');
  if (board.running) throw new Error('Dừng băng tải trước khi đổi camera.');
  if (stream) await stopCamera();
  let acquired = null;
  const videoInput = async () => (await media.enumerateDevices()).filter((item) => item.kind === 'videoinput');
  const preferred = (devices) => devices.find((item) => /c270/i.test(item.label));
  const acquire = (id) => media.getUserMedia({
    audio: false, video: {
      ...(id ? {deviceId: {exact: id}} : {}),
      width: {ideal: 1280}, height: {ideal: 720}, frameRate: {ideal: 30}
    }
  });
  try {
    let devices = await videoInput();
    const match = deviceId || preferred(devices)?.deviceId;
    if (automatic && !match && devices.some((item) => item.label)) {
      throw new Error('Không tìm thấy Logitech C270. Kiểm tra dây USB rồi bấm Mở camera.');
    }
    acquired = await acquire(match);
    devices = await videoInput();
    const actual = acquired.getVideoTracks()[0].getSettings().deviceId;
    const c270 = preferred(devices);
    if (automatic && !c270) {
      throw new Error('Không tìm thấy Logitech C270. Kiểm tra dây USB rồi bấm Mở camera.');
    }
    if (!match && c270 && c270.deviceId !== actual) {
      stopTracks(acquired);
      acquired = await acquire(c270.deviceId);
    }
    const track = acquired.getVideoTracks()[0];
    const name = track.label || 'Camera USB';
    const opened = await request('/api/camera/open', {name});
    cameraKey = opened.cameraId;
    stream = acquired;
    acquired = null;
    video.srcObject = stream;
    showMode('camera', name);
    showDetection({color: null, reason: 'Đang tự xác định mặt băng.'});
    cameraPicker.replaceChildren(...devices.map((item, index) =>
      new Option(item.label || 'Camera ' + (index + 1), item.deviceId)));
    cameraPicker.value = track.getSettings().deviceId;
    track.addEventListener('ended', () => {
      if (stream?.getVideoTracks().includes(track)) {
        handled(stopCamera());
        toast('Camera đã ngắt kết nối.', true);
      }
    });
    setText(byId('camera-button').lastElementChild, 'Tắt camera');
    setText('camera-hint', 'Đang tự tìm mặt băng');
    lastVideoTime = -1;
    await video.play();
    void sendFrame(stream, cameraKey);
  } catch (error) {
    stopTracks(acquired);
    if (stream) await stopCamera();
    throw error;
  }
}

async function sendFrame(activeStream, key) {
  if (stream !== activeStream || cameraKey !== key) return;
  const started = performance.now();
  try {
    if (video.videoWidth && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.currentTime !== lastVideoTime) {
      lastVideoTime = video.currentTime;
      const width = Math.min(640, video.videoWidth);
      encoder.width = width;
      encoder.height = Math.round(width * video.videoHeight / video.videoWidth);
      enc.drawImage(video, 0, 0, encoder.width, encoder.height);
      const image = await new Promise((resolve) => encoder.toBlob(resolve, 'image/jpeg', .9));
      if (image && stream === activeStream && cameraKey === key) {
        const result = await request('/api/frame', image, AbortSignal.timeout(1500));
        if (stream === activeStream && cameraKey === key) showDetection(result);
      }
      setText('dimensions', video.videoWidth + ' × ' + video.videoHeight);
    }
  } catch (error) {
    if (stream === activeStream) {
      toast(messageFor(error), true);
      try { await stopCamera(); } catch { /* The camera tracks have already stopped. */ }
    }
  } finally {
    if (stream === activeStream && cameraKey === key) {
      frameTimer = setTimeout(() => { void sendFrame(activeStream, key); }, Math.max(25, 160 - (performance.now() - started)));
    }
  }
}

function handled(promise) {
  promise.catch((error) => toast(messageFor(error), true));
}

async function cameraAction(deviceId, automatic = false) {
  if (cameraBusy) return;
  autoCameraPending = false;
  cameraBusy = true;
  byId('camera-button').disabled = true;
  try {
    if (stream && deviceId === undefined) await stopCamera();
    else {
      if (mode === 'idle') showMode('idle', 'Đang mở camera…');
      await startCamera(deviceId, automatic);
    }
  } catch (error) {
    if (mode === 'idle') {
      showMode('idle', 'Camera chưa mở');
      showDetection({reason: messageFor(error)});
    }
    throw error;
  } finally {
    cameraBusy = false;
    byId('camera-button').disabled = false;
    renderState();
  }
}

async function plcAction(action, extra = {}) {
  await request('/api/plc', {action, port: port.value, ...extra});
  await refresh();
}

function confirmOutputs(startAfter) {
  confirmStarts = startAfter;
  byId('legacy-check').checked = false;
  byId('confirm-legacy').disabled = true;
  setText('confirm-legacy', startAfter ? 'Xác nhận và Start' : 'Xác nhận điều khiển');
  legacyDialog.showModal();
}

async function startSystem() {
  if (openingForStart || board?.running) return;
  if (board?.profile === 'monitor') {
    confirmOutputs(true);
    return;
  }
  const attempt = ++startIntent;
  openingForStart = true;
  renderState();
  try {
    if (!stream) await cameraAction();
    const deadline = performance.now() + 7000;
    while (attempt === startIntent && stream && performance.now() < deadline) {
      await refresh();
      if (attempt !== startIntent) return;
      if (board?.connected && board.calibrated) {
        await plcAction('start');
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 180));
    }
    if (attempt === startIntent) throw new Error('Chưa tự xác định được băng tải. Kiểm tra camera nhìn thấy đủ mặt băng rồi bấm Start lại.');
  } finally {
    if (attempt === startIntent) {
      openingForStart = false;
      renderState();
    }
  }
}

async function stopSystem() {
  startIntent++;
  openingForStart = false;
  renderState();
  if (board?.connected) await plcAction('stop');
}

async function acceptOutputs() {
  legacyDialog.close();
  const shouldStart = confirmStarts;
  const intent = startIntent;
  await plcAction('legacy', {confirmed: byId('legacy-check').checked});
  if (!shouldStart) return;
  const deadline = performance.now() + 2000;
  while (intent === startIntent && performance.now() < deadline) {
    await refresh();
    if (intent !== startIntent) return;
    if (board?.connected && board.profile === 'legacy') {
      await startSystem();
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 120));
  }
  if (intent === startIntent) throw new Error('PLC chưa xác nhận quyền điều khiển.');
}

byId('camera-button').addEventListener('click', () => handled(cameraAction()));
cameraPicker.addEventListener('change', () => handled(cameraAction(cameraPicker.value)));
byId('expand').addEventListener('click', () => handled(
  document.fullscreenElement ? document.exitFullscreen() : screen.requestFullscreen()));
byId('connect').addEventListener('click', () => handled(plcAction(board?.profile && board.profile !== 'offline' ? 'disconnect' : 'connect')));
byId('start').addEventListener('click', () => handled(startSystem()));
byId('stop').addEventListener('click', () => handled(stopSystem()));
for (const [button, action] of [['trigger', 'bench'], ['reset', 'reset']]) {
  byId(button).addEventListener('click', () => handled(plcAction(action)));
}
document.querySelectorAll('.relay-control').forEach((button) => button.addEventListener('click', () =>
  handled(plcAction(button.dataset.action, {channel: Number(button.dataset.channel)}))));
byId('legacy-button').addEventListener('click', () => confirmOutputs(false));
byId('legacy-check').addEventListener('change', (event) => {
  byId('confirm-legacy').disabled = !event.target.checked;
});
byId('cancel-legacy').addEventListener('click', () => legacyDialog.close());
byId('confirm-legacy').addEventListener('click', () => handled(acceptOutputs()));
new ResizeObserver(draw).observe(screen);
window.addEventListener('pagehide', () => {
  clearTimeout(frameTimer);
  stopTracks(stream);
  stream = null;
  if (cameraKey && board) {
    void fetch('/api/camera/close', {method: 'POST', keepalive: true, body: '{}',
      headers: {'X-Sorter-Token': board.token, 'X-Sorter-Camera': cameraKey}}).catch(() => {});
  }
  if (board?.manualTarget != null) {
    void fetch('/api/plc', {method: 'POST', keepalive: true, body: '{"action":"stop"}',
      headers: {'X-Sorter-Token': board.token}}).catch(() => {});
  }
});
void refresh();
setInterval(refresh, 430);
setInterval(() => {
  if (board?.manualTarget != null) void request('/api/plc', {action: 'manual-ping'}).catch(() => {});
}, 850);
