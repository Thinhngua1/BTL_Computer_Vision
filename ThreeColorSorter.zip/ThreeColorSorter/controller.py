from collections import Counter
from dataclasses import dataclass, field
from queue import Empty, Queue
from threading import Thread
from time import monotonic

from plc import MANUAL_VERSION, SIGNATURE, STATUS, OutputMismatch, Plc
from vision import Color


class Cycle:
    """Accept three consecutive fresh, matching reads after the belt settles."""

    SETTLE = 0.25
    DEADLINE = 1.8

    def __init__(self, now):
        self.started = now
        self.last_stamp = now
        self.last_color = None
        self.matches = 0
        self.submitted = False
        self.cleared = False
        self.color = None

    def sample(self, now, stamp, detection):
        if self.submitted or stamp <= max(self.last_stamp, self.started + self.SETTLE):
            return
        if now - stamp > 0.55:
            return
        self.last_stamp = stamp
        color = detection.color
        self.matches = self.matches + 1 if color == self.last_color and color is not None else 1
        self.last_color = color

    def ready(self, now):
        if self.submitted:
            return False
        if self.last_color is not None and self.matches >= 3:
            self.color = self.last_color
            return True
        return now >= self.started + self.DEADLINE


@dataclass
class TrackedPart:
    box: tuple[int, int, int, int]
    color: Color
    seen: int = 1
    missed: int = 0
    counted: bool = False


@dataclass
class LegacyAuto:
    CONFIRM_FRAMES = 3

    last_stamp: float = 0.0
    parts: list[TrackedPart] = field(default_factory=list)
    empty_frames: int = 0
    relay: Color | None = None
    relay_releasing: bool = False


def detection_from(live):
    if len(live) == 2:
        return live[1]
    _, frame, classifier, background = live
    return classifier.classify(frame, background)


class Controller:
    def __init__(self, settings, frame_source, connect=Plc.open, *, legacy_frame_source=None):
        self.settings = settings
        self.frame_source = frame_source
        self.legacy_frame_source = legacy_frame_source or frame_source
        self.connect = connect
        self.commands = Queue()
        self.events = Queue()
        self.plc = None
        self.running = False
        self.cycle = None
        self.last_done = False
        self.heartbeat_value = True
        self.heartbeat_due = 0.0
        self.counters = Counter()
        self.profile = 'offline'
        self.manual_supported = False
        self.manual_hold_relays = False
        self.manual_target = None
        self.manual_lease = 0.0
        self.watch_signals = False
        self.signal_snapshot = None
        self.signal_due = 0.0
        self.legacy_auto = None
        self.thread = Thread(target=self._work, daemon=True)
        self.thread.start()

    def send(self, command, argument=None):
        self.commands.put((command, argument))

    def _publish(self, message):
        self.events.put((self.plc is not None and self.profile != 'monitor',
                         self.running, self.counters.copy(), message))

    def _poll_signals(self):
        self.signal_snapshot = {**self.plc.signals(), 'stamp': monotonic()}
        self.signal_due = monotonic() + 0.42
        outputs = self.signal_snapshot['outputs']
        if self.manual_target is not None:
            channel = self.manual_target
            if outputs != tuple(index == channel for index in range(3)):
                commands = self.signal_snapshot['commands']
                self._manual_stop()
                raise OutputMismatch(channel, outputs, 'khi điều khiển tay', commands)
        flow = self.legacy_auto
        if flow is None:
            return
        expected = (True, flow.relay == Color.BLACK, flow.relay == Color.BLUE)
        if flow.relay_releasing and outputs == (True, False, False):
            self._legacy_lamp_off(flow)
            return
        if outputs != expected:
            channel = 1 if flow.relay == Color.BLACK else 2 if flow.relay == Color.BLUE else 0
            commands = self.signal_snapshot['commands']
            self._stop()
            raise OutputMismatch(channel, outputs, 'khi giữ tín hiệu tự động', commands)

    def _manual_stop(self):
        if self.profile == 'legacy':
            self.plc.legacy_stop()
        else:
            self.plc.manual_stop()
        self.manual_target = None
        self.signal_due = 0.0

    def _manual_start(self, channel):
        if self.running or self.manual_target is not None:
            raise ValueError('Bấm Stop trước khi chọn ngõ ra khác.')
        if not self.manual_supported or (channel != 0 and not self.manual_hold_relays):
            raise ValueError('Chưa chọn được chương trình hỗ trợ điều khiển tay.')
        try:
            if self.profile == 'legacy':
                if self.plc.read_coils(STATUS, 10)[4:] == SIGNATURE:
                    raise ValueError('PLC đã đổi chương trình. Ngắt và kiểm tra lại.')
                self.plc.legacy_output(channel, hold=True)
            else:
                self.plc.manual_output(channel)
        except OSError:
            self.manual_target = channel
            raise
        self.manual_target = channel
        self.manual_lease = monotonic() + 3.0
        self.heartbeat_due = 0.0
        self.signal_due = 0.0
        self._publish(f'Đã bật Y{channel} để kiểm tra.')

    def _poll_manual(self):
        now = monotonic()
        if now >= self.manual_lease:
            self._manual_stop()
            self._publish('Đã tắt ngõ ra vì mất phiên điều khiển tay.')
        elif self.profile == 'auto' and now >= self.heartbeat_due:
            if self.plc.status().fault:
                self._manual_stop()
                self._publish('PLC báo lỗi. Đã tắt điều khiển tay.')
                return
            self.heartbeat_value = not self.heartbeat_value
            self.plc.heartbeat(self.heartbeat_value)
            self.heartbeat_due = now + 0.35

    def _stop(self):
        self.running = False
        self.cycle = None
        self.last_done = False
        self.legacy_auto = None
        if self.profile == 'legacy':
            self.plc.legacy_stop()
        else:
            self.plc.stop()
        self.signal_due = 0.0

    def _disconnect(self):
        if self.plc is None:
            return
        try:
            if self.manual_target is not None:
                self._manual_stop()
            elif self.running:
                self._stop()
        finally:
            self.plc.close()
            self.plc = None
            self.running = False
            self.profile = 'offline'
            self.manual_target = None
            self.manual_supported = False
            self.manual_hold_relays = False
            self.watch_signals = False
            self.signal_snapshot = None
            self.legacy_auto = None

    def _command(self, command, argument):
        if command == 'connect':
            self._disconnect()
            self.plc = self.connect(argument, self.settings)
            self.profile = 'auto'
            self._publish(f'Đã xác minh ThreeColorSorter trên {argument}.')
        elif command == 'adopt':
            self._disconnect()
            self.plc, compatible = argument
            self.profile = 'auto' if compatible else 'monitor'
            self.manual_supported, self.manual_hold_relays = (
                self.plc.read_coils(MANUAL_VERSION, 2) if compatible else (False, False)
            )
            self.watch_signals = True
            self.signal_due = 0.0
            self._publish('Đã xác minh chương trình ba màu.' if compatible else
                          'Đã kết nối Modbus ở chế độ giám sát I/O.')
        elif command == 'disconnect':
            self._disconnect()
            self._publish('Đã ngắt PLC.')
        elif self.plc is None:
            raise ValueError('Kết nối PLC trước.')
        elif command == 'legacy':
            if self.profile != 'monitor' or self.plc.read_coils(STATUS, 10)[4:] == SIGNATURE:
                raise ValueError('Không thể bật quyền điều khiển cho kết nối PLC này.')
            self.profile = 'legacy'
            self.manual_supported = self.manual_hold_relays = True
            self._publish('Đã xác nhận Y0 băng tải, Y1 đèn phôi đen và Y2 đèn phôi xanh dương.')
        elif command == 'manual-on':
            self._manual_start(argument)
        elif command == 'manual-off':
            if self.manual_target != argument:
                raise ValueError('Ngõ ra này không được điều khiển tay.')
            self._manual_stop()
            self._publish(f'Đã tắt Y{argument}.')
        elif command == 'manual-ping':
            if self.manual_target is not None:
                self.manual_lease = monotonic() + 3.0
        elif command == 'start' and not self.running:
            if self.profile not in {'auto', 'legacy'} or self.manual_target is not None:
                raise ValueError('Kết nối PLC và dừng chế độ tay trước khi chạy tự động.')
            if self.frame_source() is None:
                raise ValueError('Cần camera đang chạy và đã tự xác định mặt băng.')
            if self.profile == 'legacy':
                if self.plc.read_coils(STATUS, 10)[4:] == SIGNATURE:
                    raise ValueError('PLC đã đổi chương trình. Kết nối lại.')
                try:
                    self.plc.legacy_output(0, hold=True)
                except OSError:
                    self.running = True
                    raise
                now = monotonic()
                self.legacy_auto = LegacyAuto(last_stamp=now)
                self.signal_due = 0.0
            else:
                self.plc.start()
            self.running = True
            self.heartbeat_value = True
            self.heartbeat_due = monotonic()
            self.cycle = None
            self.last_done = False
            self._publish('Đã chạy phân loại tự động theo màu trên mặt băng.' if
                          self.profile == 'legacy' else 'Đã yêu cầu chạy. Đợi tín hiệu X0.')
        elif command == 'stop':
            if self.manual_target is not None:
                self._manual_stop()
            elif self.profile in {'auto', 'legacy'}:
                self._stop()
                if self.watch_signals:
                    self.plc.expect_outputs_off()
            else:
                raise ValueError('Phiên hiện chỉ giám sát.')
            self.signal_due = 0.0
            self._publish('Đã dừng.')
        elif command == 'reset' and not self.running:
            self.plc.reset()
            self._publish('Đã xoá lỗi. Chọn Chạy để khởi động lại.')
        elif command == 'bench' and self.running:
            self.plc.bench_trigger()
            self._publish('Đã yêu cầu chụp thử một phôi.')

    def _poll(self):
        status = self.plc.status()
        if status.fault:
            self._stop()
            self._publish('PLC báo lỗi. Kiểm tra phôi, camera và kết nối rồi chọn Xoá lỗi.')
            return
        now = monotonic()
        if now >= self.heartbeat_due:
            self.heartbeat_value = not self.heartbeat_value
            self.plc.heartbeat(self.heartbeat_value)
            self.heartbeat_due = monotonic() + 0.35
        live = self.frame_source()
        if live is None:
            self._stop()
            self._publish('Đã dừng vì mất ảnh camera hoặc hiệu chuẩn.')
            return
        stamp = live[0]
        if status.capture:
            if self.cycle is None:
                self.cycle = Cycle(monotonic())
                self.last_done = False
                self._publish('PLC đang đợi nhận diện.')
            cycle = self.cycle
            if not cycle.submitted and stamp > max(cycle.last_stamp, cycle.started + cycle.SETTLE):
                cycle.sample(monotonic(), stamp, detection_from(live))
            if cycle.ready(monotonic()):
                self.plc.submit(cycle.color)
                cycle.submitted = True
                self._publish(f'Đã gửi {cycle.color.value}.' if cycle.color else 'Ảnh không rõ. Đã gửi mã lỗi.')
        elif self.cycle is not None and self.cycle.submitted:
            if not self.cycle.cleared:
                self.plc.clear_result()
                self.cycle.cleared = True
            if status.done and not self.last_done and self.cycle.color is not None:
                self.counters[self.cycle.color] += 1
                self._publish(f'PLC đã xử lý phôi {self.cycle.color.value.lower()}.')
                self.cycle = None
        self.last_done = status.done

    def _poll_legacy_auto(self):
        live = self.legacy_frame_source()
        if live is None:
            self._stop()
            self._publish('Đã dừng tự động vì mất ảnh camera.')
            return
        flow = self.legacy_auto
        if live[0] <= flow.last_stamp:
            return
        flow.last_stamp = live[0]
        detection = detection_from(live)
        if detection is None:
            flow.empty_frames = 0
            for part in flow.parts:
                if not part.counted:
                    part.seen = 0
            # A current frame without belt geometry is not a confirmed empty belt.
            return

        flow.empty_frames = 0 if detection.boxes else flow.empty_frames + 1
        self._track_legacy_parts(flow, detection.boxes)
        present = {part.color for part in flow.parts if part.counted}
        visible = {part.color for part in flow.parts if part.counted and part.missed == 0}
        if flow.relay is not None:
            channel = 1 if flow.relay == Color.BLACK else 2
            if flow.relay_releasing:
                if flow.relay in visible:
                    self.plc.legacy_sort_relay(channel)
                    flow.relay_releasing = False
                    self.signal_due = 0.0
            elif flow.relay not in present:
                if self.plc.legacy_release_sort_relay(channel):
                    self._legacy_lamp_off(flow)
                else:
                    flow.relay_releasing = True
                    self.signal_due = 0.0
                    if flow.empty_frames < flow.CONFIRM_FRAMES:
                        self._publish(f'PLC còn tự giữ Y{channel}. Chờ mặt băng trống để nhả đèn.')

            if flow.relay_releasing and flow.empty_frames >= flow.CONFIRM_FRAMES:
                self.plc.legacy_release_with_belt_restart()
                self._legacy_lamp_off(flow)

        if flow.relay is None:
            for channel, color in ((1, Color.BLACK), (2, Color.BLUE)):
                if color in visible:
                    self.plc.legacy_sort_relay(channel)
                    flow.relay = color
                    self.signal_due = 0.0
                    self._publish(f'PLC xác nhận đèn Y{channel} sáng cho phôi {color.value.lower()}.')
                    break

    def _legacy_lamp_off(self, flow):
        color = flow.relay
        flow.relay = None
        flow.relay_releasing = False
        self.signal_due = 0.0
        self._publish(f'PLC xác nhận đèn phôi {color.value.lower()} đã tắt.')

    def _track_legacy_parts(self, flow, boxes):
        detections = [TrackedPart((x, y, w, h), color) for x, y, w, h, color in boxes if color]
        candidates = []
        for i, part in enumerate(flow.parts):
            x, y, w, h = part.box
            for j, detection in enumerate(detections):
                if detection.color != part.color:
                    continue
                dx, dy, dw, dh = detection.box
                horizontal = abs((x + w / 2) - (dx + dw / 2)) / max(w, dw, 1)
                vertical = abs((y + h / 2) - (dy + dh / 2)) / max(h, dh, 1)
                distance = horizontal + vertical
                if distance <= 1 + 0.5 * part.missed:
                    candidates.append((distance, i, j))

        matched_parts, matched_detections = set(), set()
        for _, i, j in sorted(candidates):
            if i in matched_parts or j in matched_detections:
                continue
            matched_parts.add(i)
            matched_detections.add(j)
            part = flow.parts[i]
            part.box = detections[j].box
            part.seen += 1
            part.missed = 0
            if not part.counted and part.seen >= flow.CONFIRM_FRAMES:
                part.counted = True
                self.counters[part.color] += 1
                self._publish(f'Đã đếm một phôi {part.color.value.lower()}.')

        for i, part in enumerate(flow.parts):
            if i not in matched_parts:
                part.missed += 1
                part.seen = 0
        flow.parts = [part for part in flow.parts if part.missed < flow.CONFIRM_FRAMES]
        flow.parts.extend(detection for j, detection in enumerate(detections) if j not in matched_detections)

    def _work(self):
        try:
            while True:
                try:
                    command, argument = self.commands.get(timeout=0.085)
                    if command == 'close':
                        break
                    self._command(command, argument)
                except Empty:
                    pass
                except ValueError as error:
                    self._publish(str(error))
                except OutputMismatch as error:
                    self._output_error(error)
                except (TimeoutError, OSError) as error:
                    self._link_error(error)
                try:
                    if self.manual_target is not None:
                        self._poll_manual()
                    if self.running:
                        if self.profile == 'legacy':
                            self._poll_legacy_auto()
                        else:
                            self._poll()
                    if self.watch_signals and monotonic() >= self.signal_due:
                        self._poll_signals()
                except OutputMismatch as error:
                    self._output_error(error)
                except Exception as error:
                    self._link_error(error)
        finally:
            try:
                self._disconnect()
            except Exception:
                # A disconnected PC is covered by the PLC heartbeat watchdog.
                pass

    def _output_error(self, error):
        # OutputMismatch is reported only after a verified stop.
        self.running = False
        self.legacy_auto = None
        self.manual_target = None
        self.signal_snapshot = None
        self.signal_due = 0.0
        self._publish(f'Đã dừng. {error}')

    def _link_error(self, error):
        legacy_active = self.profile == 'legacy' and (self.running or self.manual_target is not None)
        try:
            self._disconnect()
        except Exception:
            pass
        prefix = 'Không xác minh được ngõ ra. Dùng nút dừng tại máy.' if legacy_active else 'Mất trao đổi với PLC. Kiểm tra kết nối.'
        self._publish(f'{prefix} {error}')
