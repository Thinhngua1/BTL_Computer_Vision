from http.client import HTTPConnection
import json
from threading import Thread
from time import monotonic, sleep
import unittest
from unittest.mock import Mock, patch

import cv2
import numpy as np

from test_live_vision import belt_frame, side_frame
from test_relay import LegacyWire
from plc import Plc
from web_app import DashboardServer, PUBLIC, read_settings


class DashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = DashboardServer(0, read_settings())
        cls.thread = Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join()
        cls.server.dashboard.close()
        cls.server.server_close()

    def request(self, path, payload=None, origin=None, **headers):
        connection = HTTPConnection('127.0.0.1', self.server.server_port, timeout=3)
        if origin:
            headers['Origin'] = origin
        try:
            if isinstance(payload, dict):
                payload = json.dumps(payload).encode()
                headers['Content-Type'] = 'application/json'
            connection.request('GET' if payload is None else 'POST', path, payload, headers)
            response = connection.getresponse()
            data = response.read()
            if response.getheader('Content-Type', '').startswith('application/json'):
                data = json.loads(data)
            return response.status, data
        finally:
            connection.close()

    def authenticated(self):
        status, state = self.request('/api/state')
        self.assertEqual(status, 200)
        return {'X-Sorter-Token': state['token']}

    def wait_for_profile(self, profile):
        deadline = monotonic() + 2
        while monotonic() < deadline:
            state = self.request('/api/state')[1]
            if state['profile'] == profile and not state['pending']:
                return state
            sleep(.02)
        self.fail(f'Không chuyển sang profile {profile}.')

    def test_static_routes_and_sample_classification_do_not_change_counts(self):
        for path in ('/', '/app.js', '/styles.css', '/assets/belt.jpg'):
            self.assertEqual(self.request(path)[0], 200)
        headers = self.authenticated()
        for name in ('black', 'blue', 'red'):
            status, result = self.request('/api/sample', {'name': name}, **headers)
            self.assertEqual(status, 200)
            self.assertEqual(result['color'], name)
        state = self.request('/api/state')[1]
        self.assertFalse(state['calibrated'])
        self.assertEqual(sum(state['counts'].values()), 0)
        self.assertNotEqual(self.request('/api/plc', {'action': 'start'}, **headers)[0], 200)

    def test_private_mutations_and_invalid_media(self):
        headers = self.authenticated()
        self.assertEqual(self.request('/api/plc', b'')[0], 403)
        self.assertEqual(self.request('/api/camera/open', b'', origin='http://foreign.test', **headers)[0], 403)
        self.assertEqual(self.request('/api/image', b'not an image', **headers)[0], 400)
        self.assertEqual(self.request('/settings.json')[0], 404)

    def test_intel_management_port_is_rejected_before_modbus(self):
        headers = self.authenticated()
        device = Mock(device='COM4', description='Intel(R) Active Management Technology - SOL')
        with patch('web_app.list_ports.comports', return_value=[device]):
            status, result = self.request('/api/plc', {'action': 'connect', 'port': 'COM4'}, **headers)
        self.assertEqual(status, 400)
        self.assertIn('Intel SOL', result['error'])

    def test_legacy_response_is_exposed_as_read_only_snapshot(self):
        headers = self.authenticated()
        device = Mock(device='COM8', description='USB-SERIAL CH340')
        link = Mock()
        link.status.side_effect = ValueError('Chưa có chữ ký chương trình')
        link.read_coils.return_value = (False, True, False)
        link.signals.return_value = {'inputs': (True, False, False, False),
                                     'outputs': (False, True, False), 'commands': {}}
        with patch('web_app.list_ports.comports', return_value=[device]), \
                patch('web_app.Plc.open_link', return_value=link):
            self.assertEqual(self.request('/api/plc', {'action': 'connect', 'port': 'COM8'}, **headers)[0], 200)
            try:
                state = self.wait_for_profile('monitor')
                self.assertEqual(state['outputs']['values'], [False, True, False])
                self.assertFalse(state['outputs']['compatible'])
                self.assertFalse(state['connected'])
                self.assertEqual(self.request('/api/plc', {'action': 'manual-on', 'channel': 0}, **headers)[0], 400)
                self.assertEqual(self.request('/api/plc', {'action': 'legacy'}, **headers)[0], 400)
                link.read_coils.return_value = (False,) * 10
                self.assertEqual(self.request('/api/plc', {'action': 'legacy', 'confirmed': True}, **headers)[0], 200)
                self.assertTrue(self.wait_for_profile('legacy')['manualHoldRelays'])
                self.assertEqual(self.request('/api/plc', {'action': 'manual-on', 'channel': 9}, **headers)[0], 400)
            finally:
                self.request('/api/plc', {'action': 'disconnect'}, **headers)
                self.wait_for_profile('offline')
        link.read_coils.assert_any_call(0x6000, 3)
        link.close.assert_called_once()
        link.start.assert_not_called()

    def test_webcam_automatically_locks_belt_and_releases_camera(self):
        headers = self.authenticated()
        status, camera = self.request('/api/camera/open', {'name': 'Camera test'}, **headers)
        self.assertEqual(status, 200)
        frame = cv2.imencode('.jpg', belt_frame('blue'))[1].tobytes()
        live = {**headers, 'X-Sorter-Camera': camera['cameraId']}
        try:
            status, result = self.request('/api/frame', frame, **live)
            self.assertEqual(status, 200)
            self.assertEqual(result['beltStatus'], 'searching')
            self.request('/api/frame', frame, **live)
            status, result = self.request('/api/frame', frame, **live)
            self.assertEqual(status, 200)
            self.assertEqual(result['beltStatus'], 'locked')
            self.assertEqual(result['color'], 'blue')
            self.assertEqual(result['objectCount'], 1)
            self.assertTrue(self.request('/api/state')[1]['calibrated'])
        finally:
            self.request('/api/camera/close', {}, **live)
        self.assertEqual(self.request('/api/frame', frame, **live)[0], 400)
        self.assertFalse(self.request('/api/state')[1]['calibrated'])

    def test_web_start_holds_lamp_for_a_part_outside_the_middle_of_the_belt(self):
        headers = self.authenticated()
        device = Mock(device='COM9', description='USB-SERIAL CH340')
        wire = LegacyWire(belt_rising_edge=True)
        link = Plc(wire, 1, 19200)
        part = cv2.imencode('.jpg', side_frame({170: ((24, 24, 27), 0)}))[1].tobytes()
        other_part = cv2.imencode('.jpg', side_frame({490: ((22, 30, 210), 0)}))[1].tobytes()
        obscured_belt = cv2.imencode('.jpg', np.full((360, 640, 3), 205, np.uint8))[1].tobytes()
        empty = cv2.imencode('.jpg', side_frame({}))[1].tobytes()
        _, camera = self.request('/api/camera/open', {'name': 'Camera test'}, **headers)
        live = {**headers, 'X-Sorter-Camera': camera['cameraId']}

        def feed(image):
            status, response = self.request('/api/frame', image, **live)
            self.assertEqual(status, 200, response)
            sleep(.13)
            return self.request('/api/state')[1]

        with patch('web_app.list_ports.comports', return_value=[device]), \
                patch('web_app.Plc.open_link', return_value=link):
            try:
                self.assertEqual(self.request('/api/plc', {'action': 'connect', 'port': 'COM9'}, **headers)[0], 200)
                self.wait_for_profile('monitor')
                self.assertEqual(self.request('/api/plc', {'action': 'legacy', 'confirmed': True}, **headers)[0], 200)
                self.wait_for_profile('legacy')
                for _ in range(3):
                    state = feed(part)
                self.assertTrue(state['calibrated'])
                self.assertFalse(self.server.dashboard.live_frame()[1].boxes)
                self.assertEqual(self.request('/api/plc', {'action': 'start'}, **headers)[0], 200)
                for _ in range(11):
                    state = feed(part)
                self.assertTrue(state['running'])
                self.assertEqual(state['signals']['outputs'], [True, True, False])
                self.assertTrue(state['signals']['commands']['M10'])
                self.assertEqual(state['counts']['black'], 1)
                stopped_belt_writes = sum(req[1:6] == bytes((5, 0, 1, 0xff, 0)) for req in wire.requests)
                for _ in range(6):
                    state = feed(obscured_belt)
                self.assertFalse(state['calibrated'])
                self.assertTrue(state['running'])
                self.assertEqual(state['signals']['outputs'], [True, True, False])
                for _ in range(8):
                    state = feed(other_part)
                self.assertTrue(state['running'])
                self.assertEqual(state['signals']['outputs'], [True, True, False])
                self.assertFalse(state['signals']['commands']['M10'])
                self.assertEqual(state['counts']['red'], 1)
                self.assertEqual(sum(req[1:6] == bytes((5, 0, 1, 0xff, 0)) for req in wire.requests), stopped_belt_writes)
                for _ in range(6):
                    state = feed(empty)
                self.assertTrue(state['running'])
                self.assertEqual(state['signals']['outputs'], [True, False, False])
                self.assertEqual(state['counts']['black'], 1)

                for _ in range(6):
                    state = feed(part)
                self.assertEqual(state['signals']['outputs'], [True, True, False])
                self.request('/api/camera/close', {}, **live)
                deadline = monotonic() + 2
                while state['running'] and monotonic() < deadline:
                    sleep(.05)
                    state = self.request('/api/state')[1]
                self.assertFalse(state['running'])
                self.assertFalse(any(wire.coils[0x6000 + channel] for channel in range(3)))
            finally:
                self.request('/api/camera/close', {}, **live)
                self.request('/api/plc', {'action': 'disconnect'}, **headers)
                self.wait_for_profile('offline')

    def test_idle_camera_reuses_stationary_three_part_scene_until_it_changes(self):
        headers = self.authenticated()
        _, camera = self.request('/api/camera/open', {'name': 'Camera test'}, **headers)
        live = {**headers, 'X-Sorter-Camera': camera['cameraId']}
        parts = {170: ((24, 24, 27), 0), 320: ((210, 70, 20), 0), 490: ((22, 30, 210), 0)}

        def send(frame):
            image = cv2.imencode('.jpg', frame)[1].tobytes()
            status, result = self.request('/api/frame', image, **live)
            self.assertEqual(status, 200, result)
            return result

        try:
            frame = side_frame(parts)
            for _ in range(3):
                result = send(frame)
            self.assertEqual([box[4] for box in result['boxes']], ['black', 'blue', 'red'])
            with patch.object(self.server.dashboard.vision, 'update',
                              wraps=self.server.dashboard.vision.update) as update:
                for offset in (1, 2, 0, 1):
                    stationary = send(cv2.add(frame, np.full_like(frame, offset)))
                    self.assertTrue(stationary['reused'])
                    self.assertIsNone(stationary['latency'])
                    self.assertEqual(stationary['boxes'], result['boxes'])
                update.assert_not_called()
                self.assertTrue(self.request('/api/state')[1]['calibrated'])
                del parts[320]
                changed = send(side_frame(parts))
                self.assertFalse(changed['reused'])
                self.assertEqual([box[4] for box in changed['boxes']], ['black', 'red'])
                with patch.object(self.server.dashboard, 'pending', True):
                    self.assertFalse(send(side_frame(parts))['reused'])
                resized = cv2.resize(side_frame(parts), (608, 342))
                self.assertFalse(send(resized)['reused'])
                self.assertEqual(update.call_count, 3)
            state = self.request('/api/state')[1]
            self.assertEqual(sum(state['counts'].values()), 0)
        finally:
            self.request('/api/camera/close', {}, **live)


if __name__ == '__main__':
    unittest.main()
