from collections import defaultdict
import unittest
from unittest.mock import patch

from controller import Controller
from plc import OUTPUTS, OutputMismatch, Plc, with_crc
from test_sorter import FakeSerial, SETTINGS, SimulatedPLC


class LegacyWire(FakeSerial):
    def __init__(self, *, latch_outputs=True, belt_rising_edge=False):
        super().__init__()
        self.coils = defaultdict(bool)
        self.closed = False
        self.latch_outputs = latch_outputs
        self.belt_rising_edge = belt_rising_edge

    def close(self):
        self.closed = True

    def write(self, request):
        if with_crc(request[:-2]) != request:
            raise AssertionError('CRC')
        self.requests.append(request)
        start = int.from_bytes(request[2:4], 'big')
        count = int.from_bytes(request[4:6], 'big')
        if request[1] == 5:
            if start not in (0, 1, 10, 11) or count not in (0, 0xFF00):
                raise AssertionError('Invalid reference PLC single-coil write')
            was_on = self.coils[start]
            self.coils[start] = count == 0xFF00
            for index, command in enumerate((0, 10, 11)):
                output = OUTPUTS + index
                latched = (self.latch_outputs or index == 0 and self.belt_rising_edge) and self.coils[output]
                requested = self.coils[command]
                if index == 0 and self.belt_rising_edge:
                    requested = start == command and requested and not was_on
                self.coils[output] = (requested or latched) and not self.coils[1]
            self.pending = with_crc(request[:6])
        elif request[1] == 1:
            size = (count + 7) // 8
            bits = sum(self.coils[start + bit] << bit for bit in range(count))
            self.pending = with_crc(request[:2] + bytes((size,)) + bits.to_bytes(size, 'little'))
        else:
            raise AssertionError('The reference transport uses FC01 and FC05')
        return len(request)


class RelayTests(unittest.TestCase):
    def test_three_legacy_channels_hold_individually_until_stop(self):
        for channel in (0, 1, 2):
            with self.subTest(channel=channel):
                wire = LegacyWire()
                plc = Plc(wire, 1, 19200)
                plc.legacy_output(channel)
                self.assertEqual(plc.read_coils(OUTPUTS, 3), tuple(i == channel for i in range(3)))
                with self.assertRaises(ValueError):
                    plc.legacy_output((channel + 1) % 3)
                plc.legacy_stop()
                self.assertEqual(plc.read_coils(OUTPUTS, 3), (False, False, False))
                self.assertTrue(plc.read_coils(1, 1)[0])
                command = (0, 10, 11)[channel]
                writes = [(int.from_bytes(req[2:4], 'big'), int.from_bytes(req[4:6], 'big'))
                          for req in wire.requests if req[1] == 5]
                self.assertIn((command, 0xFF00), writes)
                self.assertEqual(writes[:5], [(1, 0xFF00), (0, 0), (10, 0), (11, 0), (1, 0)])

    def test_belt_output_that_does_not_latch_reports_confirmed_stop(self):
        class MomentaryBelt(LegacyWire):
            def write(self, request):
                is_output_read = request[1:4] == bytes((1, 0x60, 0))
                if is_output_read and not self.coils[0]:
                    self.coils[OUTPUTS] = False
                return super().write(request)

        wire = MomentaryBelt()
        plc = Plc(wire, 1, 19200)
        with self.assertRaisesRegex(OutputMismatch, 'Y0.*sau khi nhả bit lệnh'):
            plc.legacy_output(0)
        self.assertFalse(any(plc.read_coils(OUTPUTS, 3)))
        self.assertTrue(plc.read_coils(1, 1)[0])

    def test_failed_black_output_preserves_modbus_after_confirmed_stop(self):
        class MissingBlackRelay(LegacyWire):
            def write(self, request):
                if request[1:4] == bytes((1, 0x60, 0)):
                    self.coils[OUTPUTS + 1] = False
                return super().write(request)

        wire = MissingBlackRelay()
        plc = Plc(wire, 1, 19200)
        with patch('controller.Thread'):
            controller = Controller(SETTINGS, lambda: None)
        controller.plc, controller.profile = plc, 'legacy'
        controller.running = True
        with self.assertRaisesRegex(OutputMismatch, 'Y1.*Y0 tắt, Y1 tắt, Y2 tắt') as failed:
            plc.legacy_output(1)
        controller._output_error(failed.exception)
        self.assertFalse(controller.running)
        self.assertTrue(controller.events.get()[0])
        self.assertFalse(wire.closed)
        self.assertFalse(any(plc.read_coils(OUTPUTS, 3)))

    def test_manual_output_drop_reports_plc_command_bits_before_stop(self):
        wire = LegacyWire()
        with patch('controller.Thread'):
            ctl = Controller(SETTINGS, lambda: None)
        ctl.plc, ctl.profile = Plc(wire, 1, 19200), 'legacy'
        ctl.manual_supported = ctl.manual_hold_relays = True
        ctl._command('manual-on', 1)
        wire.coils[OUTPUTS + 1] = False
        with self.assertRaisesRegex(OutputMismatch, 'M0=0, M1=0, M10=1, M11=0') as stopped:
            ctl._poll_signals()
        ctl._output_error(stopped.exception)
        self.assertIsNone(ctl.manual_target)
        self.assertFalse(any(ctl.plc.read_coils(OUTPUTS, 3)))
        self.assertTrue(ctl.plc.read_coils(1, 1)[0])

    def test_new_plc_holds_all_manual_channels_and_shuts_down_on_heartbeat_loss(self):
        for index in range(3):
            with self.subTest(channel=index):
                logic = SimulatedPLC()
                command = f'M{46 + index}'
                logic.bits[command] = True
                expected = tuple(channel == index for channel in range(3))
                self.assertTrue(logic.bits['M50'])
                self.assertEqual(logic.run_ms(4000), {expected})
                logic.bits[command] = False
                self.assertEqual(logic.scan(), (False, False, False))
                logic.bits[command] = True
                logic.run_ms(3100, heartbeat=False)
                self.assertEqual(logic.scan(), (False, False, False))
                self.assertTrue(logic.bits['M23'])
        logic.bits['M47'] = logic.bits['M48'] = True
        self.assertEqual(logic.scan(), (False, False, False))

    def test_legacy_manual_hold_exits_on_off_or_lost_browser(self):
        now = 10.0
        with patch('controller.Thread'):
            ctl = Controller(SETTINGS, lambda: None)
        ctl.plc = Plc(LegacyWire(), 1, 19200)
        ctl.profile = 'legacy'
        ctl.manual_supported = ctl.manual_hold_relays = True
        with patch('controller.monotonic', side_effect=lambda: now):
            for channel, command in enumerate((0, 10, 11)):
                ctl._command('manual-on', channel)
                with self.assertRaises(ValueError):
                    ctl._command('manual-on', (channel + 1) % 3)
                for _ in range(5):
                    now += 1
                    ctl._command('manual-ping', None)
                    ctl._poll_manual()
                    self.assertTrue(ctl.plc.read_coils(command, 1)[0])
                    self.assertEqual(ctl.plc.read_coils(OUTPUTS, 3), tuple(i == channel for i in range(3)))
                ctl._command('manual-off', channel)
                self.assertIsNone(ctl.manual_target)
                self.assertFalse(any(ctl.plc.read_coils(OUTPUTS, 3)))
            ctl._command('manual-on', 0)
            now += 3.01
            ctl._poll_manual()
            self.assertIsNone(ctl.manual_target)
            self.assertFalse(any(ctl.plc.read_coils(OUTPUTS, 3)))


if __name__ == '__main__':
    unittest.main()
