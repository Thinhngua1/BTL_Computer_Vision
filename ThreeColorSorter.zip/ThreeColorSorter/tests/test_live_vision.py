import unittest
from unittest.mock import patch

import cv2
import numpy as np

from belt_vision import BeltVision
from controller import Controller
from plc import OUTPUTS, OutputMismatch, Plc
from test_relay import LegacyWire
from test_sorter import ROOT, SETTINGS
from vision import Color, Detection


def belt_frame(color=None, outside=False):
    image = np.full((360, 640, 3), 180, np.uint8)
    cv2.rectangle(image, (216, 4), (423, 355), (210, 210, 205), -1)
    cv2.rectangle(image, (227, 4), (412, 355), (52, 50, 49), -1)
    if color:
        ink = {'black': (15, 16, 18), 'blue': (190, 62, 25), 'red': (20, 25, 210)}[color]
        x = 95 if outside else 317
        cv2.ellipse(image, (x, 169), (45, 38), 0, 0, 360, ink, -1)
        cv2.ellipse(image, (x, 161), (30, 21), 0, 0, 360, (16, 17, 18), -1)
    return image


def side_frame(parts):
    image = np.full((360, 640, 3), (172, 199, 217), np.uint8)
    cv2.fillConvexPoly(image, np.int32([[0, 131], [639, 214], [639, 253], [0, 170]]), (80, 77, 73))
    cv2.fillConvexPoly(image, np.int32([[0, 170], [639, 253], [639, 360], [0, 240]]), (147, 147, 151))
    cv2.fillConvexPoly(image, np.int32([[0, 201], [639, 309], [639, 327], [0, 218]]), (59, 61, 62))
    for x, (color, rises) in parts.items():
        base = round(170 + .13 * x - 15) - rises
        top = base - 69
        cv2.rectangle(image, (x - 44, top), (x + 44, base), color, -1)
        cv2.ellipse(image, (x, top), (44, 9), 0, 0, 360, color, -1)
        cv2.ellipse(image, (x, base), (44, 8), 0, 0, 360, color, -1)
    return image


class LiveVisionTests(unittest.TestCase):
    def test_reference_scene_detects_belt_but_excludes_three_parts_off_belt(self):
        vision = BeltVision(SETTINGS)
        reference = cv2.imread(str(ROOT / 'web/assets/belt.jpg'))
        for _ in range(3):
            result = vision.update(cv2.resize(reference, (640, 307)))
        self.assertTrue(result.ready)
        self.assertEqual(len(result.outline), 4)
        self.assertEqual(result.detection.boxes, ())
        self.assertTrue(all(x > 350 for x, _ in result.outline))

    def test_three_colors_without_manual_roi_and_lost_belt(self):
        vision = BeltVision(SETTINGS)
        for color in Color:
            for _ in range(3):
                result = vision.update(belt_frame(color.name.lower()))
            self.assertTrue(result.ready)
            self.assertEqual(result.at_station.color, color)
        result = vision.update(belt_frame('blue', outside=True))
        self.assertEqual(result.detection.boxes, ())
        self.assertEqual(vision.update(np.full((360, 640, 3), 172, np.uint8)).status, 'lost')

    def test_two_parts_at_station_do_not_select_an_actuator(self):
        vision = BeltVision(SETTINGS)
        frame = belt_frame()
        cv2.circle(frame, (275, 171), 23, (25, 25, 210), -1)
        cv2.circle(frame, (361, 175), 24, (190, 62, 25), -1)
        for _ in range(3):
            result = vision.update(frame)
        self.assertTrue(result.ready)
        self.assertEqual(len(result.detection.boxes), 2)
        self.assertIsNone(result.at_station.color)

    def test_low_camera_uses_belt_contact_and_draws_three_upright_parts(self):
        vision = BeltVision(SETTINGS)
        frame = side_frame({80: ((10, 36, 201), 65), 187: ((14, 15, 19), 0),
                            315: ((184, 60, 25), 0), 504: ((18, 24, 201), 0)})
        for _ in range(4):
            result = vision.update(frame)
        self.assertTrue(result.ready)
        self.assertAlmostEqual(result.outline[1][1], 170, delta=5)
        self.assertEqual([box[4] for box in result.detection.boxes], [Color.BLACK, Color.BLUE, Color.RED])
        self.assertEqual(result.at_station.color, Color.BLUE)
        self.assertTrue(all(box[0] > 120 for box in result.detection.boxes))
        self.assertEqual(vision.update(side_frame({})).detection.boxes, ())

    def test_laptop_behind_side_view_cannot_supply_a_color_at_station(self):
        frame = side_frame({})
        cv2.rectangle(frame, (266, 92), (364, 166), (13, 14, 17), -1)
        cv2.rectangle(frame, (261, 162), (369, 167), (19, 20, 24), -1)
        cv2.rectangle(frame, (0, 67), (80, 132), (15, 17, 18), -1)
        vision = BeltVision(SETTINGS)
        for _ in range(4):
            result = vision.update(frame)
        self.assertTrue(result.ready)
        self.assertEqual(result.detection.boxes, ())
        self.assertIsNone(result.at_station.color)

    def test_black_part_keeps_its_box_next_to_dark_background(self):
        frame = side_frame({315: ((14, 15, 19), 0)})
        cv2.rectangle(frame, (354, 77), (578, 163), (12, 15, 18), -1)
        vision = BeltVision(SETTINGS)
        for _ in range(4):
            result = vision.update(frame)
        self.assertTrue(result.ready)
        self.assertEqual(result.at_station.color, Color.BLACK)
        self.assertEqual(len(result.detection.boxes), 1)
        x, _, width, _, _ = result.detection.boxes[0]
        self.assertLess(abs(x - 271), 12)
        self.assertLess(width, 111)

    def test_side_view_relocks_after_small_camera_moves(self):
        vision = BeltVision(SETTINGS)
        frame = side_frame({187: ((14, 15, 19), 0), 315: ((184, 60, 25), 0),
                            493: ((18, 24, 201), 0)})
        h, w = frame.shape[:2]
        corners = np.float32([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]])
        tilt = cv2.getPerspectiveTransform(corners, np.float32([[22, 9], [621, 0], [639, 344], [0, 359]]))
        moves = (
            frame,
            cv2.warpAffine(frame, cv2.getRotationMatrix2D((w / 2, h / 2), -6, 1), (w, h),
                           borderMode=cv2.BORDER_REPLICATE),
            cv2.warpAffine(frame, np.float32([[1, 0, 31], [0, 1, -18]]), (w, h), borderMode=cv2.BORDER_REPLICATE),
            cv2.warpPerspective(frame, tilt, (w, h), borderMode=cv2.BORDER_REPLICATE),
        )
        for moved in moves:
            for _ in range(6):
                result = vision.update(moved)
            self.assertTrue(result.ready)
            self.assertEqual([box[4] for box in result.detection.boxes], list(Color))

    def test_legacy_holds_each_color_lamp_until_workpiece_leaves(self):
        now = 10.0
        frame = (0.0, Detection(None, 'empty'))
        with patch('controller.Thread'):
            controller = Controller(SETTINGS, lambda: frame)
        wire = LegacyWire(belt_rising_edge=True, latch_outputs=False)
        controller.profile = 'legacy'
        controller.plc = Plc(wire, 1, 19200)

        def send(*colors, unlocked=False):
            nonlocal now, frame
            now += .16
            positions = {Color.BLACK: 10, Color.BLUE: 110, Color.RED: 210}
            boxes = []
            for color in colors:
                boxes.append((positions[color], 10, 20, 20, color))
                positions[color] += 40
            frame = (now, None if unlocked else Detection(None, 'fixture', tuple(boxes)))
            controller._poll_legacy_auto()
            controller._poll_signals()
            return controller.plc.read_coils(OUTPUTS, 3)

        with patch('controller.monotonic', side_effect=lambda: now), patch('plc.sleep'):
            controller._command('start', None)
            self.assertEqual(controller.plc.read_coils(OUTPUTS, 3), (True, False, False))
            for color, channel in ((Color.BLACK, 1), (Color.BLUE, 2), (Color.RED, 0)):
                for _ in range(2):
                    self.assertEqual(send(color), (True, False, False))
                self.assertFalse(controller.counters[color])
                expected = (True, channel == 1, channel == 2)
                self.assertEqual(send(color), expected)
                self.assertEqual(controller.counters[color], 1)
                traffic = len([req for req in wire.requests if req[1] == 5])
                for _ in range(12):
                    self.assertEqual(send(color), expected)
                for _ in range(5):
                    self.assertEqual(send(unlocked=True), expected)
                self.assertTrue(controller.running)
                self.assertEqual(send(color), expected)
                self.assertEqual(send(), expected)
                self.assertEqual(send(color), expected)
                for _ in range(2):
                    self.assertEqual(send(), expected)
                self.assertEqual(len([req for req in wire.requests if req[1] == 5]), traffic)
                self.assertEqual(send(), (True, False, False))
                self.assertEqual(controller.counters[color], 1)
            for _ in range(3):
                outputs = send(Color.BLACK, Color.BLACK, Color.BLUE)
            self.assertEqual(outputs, (True, True, False))
            self.assertEqual(controller.counters[Color.BLACK], 3)
            self.assertEqual(controller.counters[Color.BLUE], 2)
            stopped_belt_writes = sum(req[1:6] == bytes((5, 0, 1, 0xff, 0)) for req in wire.requests)
            for _ in range(2):
                self.assertEqual(send(Color.BLUE), (True, True, False))
            self.assertEqual(send(Color.BLUE), (True, False, True))
            self.assertEqual(sum(req[1:6] == bytes((5, 0, 1, 0xff, 0)) for req in wire.requests), stopped_belt_writes)
            controller._command('stop', None)
            self.assertFalse(controller.running)
            self.assertFalse(any(controller.plc.read_coils(OUTPUTS, 3)))

    def test_legacy_relay_drop_reports_fault_and_preserves_confirmed_count(self):
        now = 10.0
        frame = (0.0, Detection(None, 'empty'))
        with patch('controller.Thread'):
            controller = Controller(SETTINGS, lambda: frame)
        wire = LegacyWire(belt_rising_edge=True)
        controller.profile = 'legacy'
        controller.plc = Plc(wire, 1, 19200)
        with patch('controller.monotonic', side_effect=lambda: now), patch('plc.sleep'):
            controller._command('start', None)
            for _ in range(3):
                now += .13
                frame = (now, Detection(Color.BLACK, 'black', ((10, 10, 20, 20, Color.BLACK),)))
                controller._poll_legacy_auto()
            self.assertTrue(wire.coils[10])
            wire.coils[OUTPUTS + 1] = False
            with self.assertRaisesRegex(OutputMismatch, 'Y1.*giữ tín hiệu tự động.*M10=1'):
                controller._poll_signals()
            self.assertFalse(controller.running)
            self.assertEqual(controller.counters[Color.BLACK], 1)
            self.assertTrue(wire.coils[1])
            self.assertFalse(any(controller.plc.read_coils(OUTPUTS, 3)))


if __name__ == '__main__':
    unittest.main()
