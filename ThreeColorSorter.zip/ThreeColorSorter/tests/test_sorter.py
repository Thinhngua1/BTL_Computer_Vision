from collections import defaultdict
import json
from pathlib import Path
from struct import pack
import unittest
from unittest.mock import Mock, patch

import cv2
import numpy as np

from controller import Controller, Cycle
from plc import Plc, RESULT_MASK, SIGNATURE, Status, with_crc
from vision import Classifier, Color, Detection


ROOT = Path(__file__).resolve().parents[1]
SETTINGS = json.loads((ROOT / 'settings.json').read_text())


class ImageTests(unittest.TestCase):
    def setUp(self):
        self.base = np.full((360, 640, 3), (56, 52, 50), np.uint8)
        self.classifier = Classifier(SETTINGS)

    def part(self, ink, center=(300, 195)):
        frame = self.base.copy()
        cv2.ellipse(frame, center, (51, 40), 0, 0, 360, ink, cv2.FILLED)
        cv2.ellipse(frame, (center[0], center[1] - 10), (35, 24), 0, 0, 360, (20, 18, 16), cv2.FILLED)
        return frame

    def test_three_hollow_workpieces_against_dark_belt(self):
        for ink, color in [((19, 18, 17), Color.BLACK),
                           ((216, 67, 35), Color.BLUE),
                           ((32, 25, 205), Color.RED)]:
            with self.subTest(color=color):
                result = self.classifier.classify(self.part(ink), self.base)
                self.assertEqual(result.color, color)
                self.assertEqual(len(result.boxes), 1)

    def test_blue_cast_on_black_is_still_black(self):
        light = np.full_like(self.base, 185)
        blue_cast = np.uint8([[[112, 97, 52]]])
        bgr = tuple(int(channel) for channel in cv2.cvtColor(blue_cast, cv2.COLOR_HSV2BGR)[0, 0])
        cv2.circle(light, (315, 184), 58, bgr, cv2.FILLED)
        self.assertEqual(self.classifier.classify(light, None).color, Color.BLACK)

    def test_empty_dark_belt_and_uncertain_shape(self):
        self.assertIsNone(self.classifier.classify(self.base, self.base).color)
        barely_visible = self.base.copy()
        cv2.circle(barely_visible, (300, 195), 50, (54, 52, 50), -1)
        self.assertIsNone(self.classifier.classify(barely_visible, self.base).color)
        self.assertIsNone(self.classifier.classify(self.part((35, 160, 35)), self.base).color)

    def test_red_on_both_sides_of_hue_wrap(self):
        for hue in (2, 172):
            with self.subTest(hue=hue):
                hsv = np.uint8([[[hue, 210, 165]]])
                ink = tuple(int(channel) for channel in cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)[0, 0])
                self.assertEqual(self.classifier.classify(self.part(ink), self.base).color, Color.RED)

    def test_background_size_mismatch_is_rejected(self):
        frame = self.part((32, 25, 205))
        self.assertIsNone(self.classifier.classify(frame, self.base[:-1]).color)

    def test_multiple_objects_and_clipped_part(self):
        frame = self.part((20, 25, 210), (200, 195))
        cv2.circle(frame, (400, 198), 48, (200, 40, 25), -1)
        result = self.classifier.classify(frame, self.base)
        self.assertIsNone(result.color)
        self.assertEqual(len(result.boxes), 2)
        self.assertIsNone(self.classifier.classify(self.part((200, 40, 25), (66, 190)), self.base).color)

    def test_stale_and_unstable_frames_are_rejected(self):
        cycle = Cycle(10)
        red, blue = Detection(Color.RED, ''), Detection(Color.BLUE, '')
        cycle.sample(10.4, 10.2, red)
        cycle.sample(10.4, 10.3, red)
        cycle.sample(10.5, 10.3, red)
        cycle.sample(10.5, 10.4, blue)
        cycle.sample(10.6, 10.55, red)
        self.assertFalse(cycle.ready(10.6))
        cycle.sample(10.7, 10.65, red)
        cycle.sample(10.8, 10.75, red)
        self.assertTrue(cycle.ready(10.8))
        self.assertEqual(cycle.color, Color.RED)
        other = Cycle(10)
        self.assertTrue(other.ready(12))
        self.assertIsNone(other.color)


class FakeSerial:
    def __init__(self, state=0b1011010000):
        self.pending = b''
        self.requests = []
        self.state = state
        self.bad_crc = False

    def reset_input_buffer(self):
        self.pending = b''

    def write(self, request):
        if with_crc(request[:-2]) != request:
            raise AssertionError('CRC request')
        self.requests.append(request)
        station, function = request[:2]
        if function == 1:
            self.pending = with_crc(bytes((station, function, 2)) + pack('<H', self.state))
        else:
            self.pending = with_crc(request[:6])
        if self.bad_crc:
            self.pending = self.pending[:-1] + bytes((self.pending[-1] ^ 1,))
        return len(request)

    def read(self, size):
        data, self.pending = self.pending[:size], self.pending[size:]
        return data


class ProtocolTests(unittest.TestCase):
    def test_signature_and_atomic_result_masks(self):
        expected = sum(value << (4 + i) for i, value in enumerate(SIGNATURE))
        serial = FakeSerial(expected)
        plc = Plc(serial, 1, 19200)
        with self.assertRaises(RuntimeError):
            plc.submit(Color.BLACK)
        self.assertFalse(plc.status().busy)
        for color, bitmask in RESULT_MASK.items():
            plc.submit(color)
            self.assertEqual(serial.requests[-1][1:-2], bytes((15, 0, 10, 0, 4, 1, bitmask)))
        plc.start()
        self.assertEqual(serial.requests[-1][1:-2], bytes((15, 0, 0, 0, 3, 1, 5)))
        plc.stop()
        self.assertEqual(serial.requests[-2][1:-2], bytes((15, 0, 0, 0, 3, 1, 0)))

    def test_bad_crc_and_incorrect_signature_block_operation(self):
        serial = FakeSerial(0)
        plc = Plc(serial, 1, 19200)
        with self.assertRaises(ValueError):
            plc.status()
        with self.assertRaises(RuntimeError):
            plc.heartbeat(True)
        serial.bad_crc = True
        with self.assertRaises(OSError):
            plc.status()
        self.assertEqual([r[1] for r in serial.requests], [1, 1])

    def test_loss_of_camera_stops_a_running_plc(self):
        with patch('controller.Thread'):
            controller = Controller(SETTINGS, lambda: None)
        link = Mock()
        link.status.return_value = Status(False, False, False, False)
        controller.plc = link
        with self.assertRaises(ValueError):
            controller._command('start', None)
        link.start.assert_not_called()
        controller.running = True
        controller._poll()
        self.assertFalse(controller.running)
        link.stop.assert_called_once()
        link.submit.assert_not_called()

    def test_done_is_counted_once_per_piece(self):
        with patch('controller.Thread'):
            controller = Controller(SETTINGS, lambda: (10, None, None, None))
        link = Mock()
        link.status.side_effect = [Status(False, True, False, False),
                                   Status(False, False, True, False),
                                   Status(False, False, True, False)]
        controller.plc = link
        controller.running = True
        controller.cycle = Cycle(1)
        controller.cycle.color = Color.RED
        controller.cycle.submitted = True
        controller._poll()
        self.assertEqual(controller.counters[Color.RED], 0)
        controller._poll()
        controller._poll()
        self.assertEqual(controller.counters[Color.RED], 1)
        link.clear_result.assert_called_once()

    def test_crc_reference(self):
        self.assertEqual(with_crc(b'123456789')[-2:], bytes((0x37, 0x4B)))


class SimulatedPLC:
    """Interpret the delivered IL in order at a fixed 10 ms scan."""

    def __init__(self):
        text = (ROOT / 'plc' / 'ThreeColorSorter.il.txt').read_text(encoding='ascii')
        self.code = [line.split() for line in text.splitlines() if line.strip() and not line.startswith('//')]
        self.bits = defaultdict(bool, {'SM0': True, 'SM2': True})
        self.elapsed = defaultdict(int)
        self.scan()

    def scan(self):
        result = False
        for operation, *args in self.code:
            if operation == 'END':
                break
            flag = args[0]
            value = self.bits[flag]
            if operation == 'LD':
                result = value
            elif operation == 'LDI':
                result = not value
            elif operation == 'AND':
                result = result and value
            elif operation == 'ANI':
                result = result and not value
            elif operation == 'OR':
                result = result or value
            elif operation == 'OUT':
                self.bits[flag] = result
            elif operation in ('SET', 'RST'):
                if result:
                    self.bits[flag] = operation == 'SET'
            elif operation == 'TMR':
                self.elapsed[flag] = self.elapsed[flag] + 10 if result else 0
                self.bits[flag] = self.elapsed[flag] >= int(args[1][1:]) * int(args[2][1:])
            else:
                raise AssertionError(f'Unsupported IL operation: {operation}')
        self.bits['SM2'] = False
        return tuple(self.bits['Y' + str(i)] for i in range(3))

    def run_ms(self, duration, heartbeat=True):
        previous = set()
        for elapsed in range(0, duration, 10):
            if heartbeat and elapsed % 350 == 0:
                self.bits['M2'] = not self.bits['M2']
            state = self.scan()
            if state[1] and state[2] or state[0] and any(state[1:]):
                raise AssertionError('Mutually exclusive outputs')
            previous.add(state)
        return previous

    def run_until_capture(self):
        self.bits['M0'] = True
        self.run_ms(50)
        self.bits['X0'] = True
        state = self.scan()
        if not self.bits['M20'] or state != (False, False, False):
            raise AssertionError('Missing capture or belt did not stop')

    def send_result(self, packed):
        for index in range(4):
            self.bits['M' + str(10 + index)] = bool(packed & (1 << index))


class LadderTests(unittest.TestCase):
    def test_pc_frames_drive_the_same_il_that_reports_status(self):
        class Loopback(FakeSerial):
            def __init__(self, logic):
                super().__init__()
                self.logic = logic

            def write(self, request):
                if request[1] == 15:
                    start = int.from_bytes(request[2:4], 'big')
                    count = int.from_bytes(request[4:6], 'big')
                    for bit in range(count):
                        self.logic.bits[f'M{start + bit}'] = bool(request[7] & (1 << bit))
                    self.logic.scan()
                self.state = sum(self.logic.bits[f'M{20 + bit}'] << bit for bit in range(10))
                return super().write(request)

        for color, actuator in ((Color.BLACK, (False, True, False)),
                                (Color.BLUE, (False, False, True)),
                                (Color.RED, (True, False, False))):
            with self.subTest(color=color):
                logic = SimulatedPLC()
                plc = Plc(Loopback(logic), 1, 19200)
                plc.status()
                plc.start()
                logic.bits['X0'] = True
                logic.scan()
                self.assertTrue(plc.status().capture)
                plc.submit(color)
                self.assertFalse(plc.status().capture)
                self.assertTrue(plc.status().busy)
                plc.clear_result()
                states = logic.run_ms(2900)
                self.assertIn(actuator, states)
                if color == Color.RED:
                    self.assertFalse(any(y1 or y2 for _, y1, y2 in states))
                self.assertTrue(plc.status().done)
                plc.stop()
                self.assertFalse(any(logic.scan()))

    def test_three_paths_and_no_retrigger_while_sensor_high(self):
        for color, expected in ((Color.BLACK, (False, True, False)),
                                (Color.BLUE, (False, False, True)),
                                (Color.RED, (True, False, False))):
            with self.subTest(color=color):
                plc = SimulatedPLC()
                self.assertEqual(tuple(plc.bits[f'M{n}'] for n in range(24, 30)), SIGNATURE)
                plc.run_until_capture()
                plc.send_result(RESULT_MASK[color])
                states = plc.run_ms(2900)
                self.assertIn(expected, states)
                self.assertTrue(plc.bits['M22'])
                self.assertFalse(plc.bits['M21'])
                if color == Color.RED:
                    self.assertFalse(any(y1 or y2 for _, y1, y2 in states))
                plc.send_result(0)
                plc.run_ms(50)
                self.assertFalse(plc.bits['M20'])
                plc.bits['X0'] = False
                plc.scan()
                plc.bits['X0'] = True
                plc.scan()
                self.assertTrue(plc.bits['M20'])

    def test_invalid_code_watchdog_and_no_result_timeout(self):
        for case in ('unknown', 'multi', 'heartbeat', 'timeout'):
            with self.subTest(case=case):
                plc = SimulatedPLC()
                plc.run_until_capture()
                if case in ('unknown', 'multi'):
                    plc.send_result(8 if case == 'unknown' else 11)
                plc.run_ms(5100, heartbeat=case != 'heartbeat')
                self.assertTrue(plc.bits['M23'])
                self.assertFalse(any(plc.scan()))
                self.assertFalse(plc.bits['M21'])

    def test_stop_clears_push_and_fault_requires_reset(self):
        plc = SimulatedPLC()
        plc.run_until_capture()
        plc.send_result(RESULT_MASK[Color.BLACK])
        self.assertIn((False, True, False), plc.run_ms(1050))
        plc.bits['M0'] = False
        self.assertFalse(any(plc.scan()))
        plc.send_result(0)
        plc.bits['X0'] = False
        plc.run_until_capture()
        plc.send_result(RESULT_MASK[None])
        plc.scan()
        self.assertTrue(plc.bits['M23'])
        plc.bits['M0'] = False
        plc.bits['M1'] = True
        self.assertFalse(any(plc.scan()))
        self.assertFalse(plc.bits['M23'])


if __name__ == '__main__':
    unittest.main()
