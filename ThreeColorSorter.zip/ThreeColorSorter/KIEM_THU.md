# Kiểm thử ThreeColorSorter

Chạy các ca kiểm từ thư mục repo bằng lệnh sau. Bộ kiểm thử dùng ảnh dựng, máy chủ web cục bộ và PLC mô phỏng.

```powershell
& .\.venv\Scripts\python.exe -X utf8 -B -m unittest discover -s tests -v
```

| Hạng mục | Hành vi được kiểm |
| --- | --- |
| Tìm băng và nhận diện | Ba màu trên băng, vật ngoài băng, nền tối, hai góc camera và dịch camera nhẹ |
| Dashboard | Mở/đóng camera, kết quả hình ảnh, khôi phục mặt băng và giữ kết quả khi cảnh đứng yên |
| Giao tiếp PLC | Kiểm CRC, địa chỉ coil, đọc trả về của ngõ ra và từ chối cấu hình sai |
| Băng tải và đèn | Giữ Y0 qua các khung thiếu dấu băng, giữ đèn khi phôi còn trong ảnh, nhả theo kết quả đọc lại |
| Bộ đếm | Đếm khi xác nhận qua ba ảnh mới, tránh đếm lặp phôi đứng yên, nhận riêng hai phôi cùng màu |
| Dừng | Dừng theo lệnh hoặc khi mất luồng camera, xử lý ngõ ra PLC không khớp lệnh |

Khi chạy tại máy, đối chiếu cổng COM, vị trí camera và ánh xạ ngõ ra trước khi thử. Quan sát từng màu khi vào và rời khung, rồi đối chiếu đèn, bộ đếm và phản hồi Y0–Y2 trên dashboard. Kiểm thử tự động bao phủ logic phần mềm và mô hình PLC. Kết quả vận hành cơ khí hoặc điện cần kiểm trên hệ thống đã lắp.
