# Chương trình Xinje XD2

[ThreeColorSorter.il.txt](ThreeColorSorter.il.txt) là nguồn chương trình dạng Instruction List. Tạo project XD2-16 trong XDPPro. Nhập các lệnh theo thứ tự ở chế độ Instruction List hoặc dựng Ladder từ từng khối lệnh ngăn cách bằng dòng trắng. Các dòng bắt đầu bằng `//` là chú thích. Chuyển sang Ladder và chạy Compile All trong XDPPro trước khi nạp. [Hướng dẫn XDPPro, mục 5.1–5.2](https://match.xinje.com/uploads/admin/202412/6753163d25604.pdf)

## I/O dự kiến

| Điểm | Thiết bị hoặc tín hiệu |
| --- | --- |
| X0 | Cảm biến có phôi tại vị trí chụp. ON khi có phôi. PLC chỉ nhận lượt mới sau khi X0 đã OFF. |
| Y0 | Tín hiệu chạy băng tải. |
| Y1 | Van đẩy phôi đen. |
| Y2 | Van đẩy phôi xanh dương. |
| Đỏ | Đi thẳng, Y1 và Y2 OFF. |

Ánh xạ trên kế thừa dự án ban đầu và cần đối chiếu với dây tại máy. Chương trình giả định mất điện van thì xi lanh thu về, tốc độ băng tải ổn định và chỉ có một phôi trong chu kỳ. Khi nhận X0, PLC dừng băng để chụp, sau đó chạy đến cửa phân loại theo timer. Vị trí thực còn phụ thuộc tốc độ tải và quãng trượt sau khi tắt Y0.

## Coil PC và PLC

| Coil | Bên điều khiển | Chức năng |
| --- | --- | --- |
| M0 | PC | Yêu cầu chạy, OFF để dừng. |
| M1 | PC | Xoá lỗi khi M0 OFF. |
| M2 | PC | Heartbeat đảo bit sau mỗi 350 ms. |
| M6 | PC | Yêu cầu chụp thử khi đang chạy và rảnh. PLC xoá sau khi nhận. |
| M10 / M11 / M12 | PC | Đen / xanh dương / đỏ, đặt tối đa một bit. |
| M13 | PC | Xác nhận kết quả. Chỉ đặt M13 để báo ảnh không rõ. Ghi M10–M13 bằng một lệnh FC15. |
| M20 | PLC | Đang yêu cầu kết quả từ camera. |
| M21 / M22 / M23 | PLC | Đang xử lý / đã xong / lỗi cần xoá. |
| M24–M29 | PLC | Tín hiệu nhận diện chương trình `101101` theo thứ tự địa chỉ tăng dần. |
| M46 | PC | Start tay Y0. PLC giám sát heartbeat trong lúc giữ. |
| M47 / M48 | PC | Giữ Y1 / Y2 đến khi tắt lệnh. PLC chặn khi Y0 đang chạy tay. |
| M49 | PLC | Báo chương trình hỗ trợ điều khiển tay. |
| M50 | PLC | Báo chương trình hỗ trợ giữ Y1 và Y2. |

PC đợi M20 OFF rồi xoá M10–M13. PLC giữ M22 đến chu kỳ tiếp theo hoặc khi dừng. Không đặt M0–M13 từ một Modbus master khác trong lúc ứng dụng chạy. Coil M sử dụng địa chỉ PDU tính từ 0. [Đặc tả Modbus, FC01 và FC15](https://www.modbus.org/file/secure/modbusprotocolspecification.pdf)

## Timer ban đầu

| Timer | Mặc định | Cách xác định tại máy |
| --- | ---: | --- |
| T0 | 3.0 s | Watchdog PLC khi PC không đảo heartbeat. |
| T1 | 5.0 s | PLC đợi kết quả mỗi lượt. |
| T2 | 1.0 s | Đo thời gian chạy từ điểm chụp đến xi lanh đen. |
| T3 | 1.8 s | Đo thời gian chạy từ điểm chụp đến xi lanh xanh dương. |
| T4 | 2.8 s | Đo thời gian phôi đỏ rời vùng phân loại. |
| T5, T6 | 0.5 s | Đo thời gian xi lanh cần để đẩy phôi ra khỏi băng. |
| T7 | 0.6 s | Đo thời gian xi lanh thu trước khi Y0 chạy lại. |

`TMR Tn Kn K100` dùng thời cơ sở 100 ms. Kiểm tra trên máy theo từng tuyến và quan sát lúc mất kết nối. Mã lỗi, timeout hoặc hết heartbeat đều xoá trạng thái chu kỳ và tắt Y0/Y1/Y2 trong logic PLC. [Hướng dẫn phần cứng và relay hệ thống Xinje](https://cdn-en.xinje.com/XDXL%20hardware%20manual.pdf)

Dashboard đọc vùng ngõ vào từ `0x5000`, ngõ ra từ `0x6000`, và đổi lệnh qua coil M. Với `PLC.xdp` tham chiếu, dashboard dùng FC05 để giữ M0, M10 hoặc M11 cho Y0, Y1 hoặc Y2 khi điều khiển tay. Khi chạy tự động, web giữ M10 hoặc M11 cùng với M0 trong lúc còn thấy phôi tương ứng. Khi phôi rời khung, web tắt M10 hoặc M11 và đọc Y1/Y2. Nếu chương trình PLC còn tự giữ đèn, web đợi ba khung hợp lệ xác nhận băng trống rồi đặt M1 để nhả đèn và cấp cạnh lên M0 để chạy tiếp. Dừng tại máy nếu đường Modbus bị ngắt khi ngõ ra còn tự giữ. [Bảng địa chỉ Xinje XD/XL](https://cdn-en.xinje.com/TCPIP%20communication%20manual.pdf)
