from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from threading import Event, Lock, Thread
from time import monotonic

import cv2
import numpy as np
from cv2_enumerate_cameras import enumerate_cameras


class Color(Enum):
    BLACK = 'Đen'
    BLUE = 'Xanh dương'
    RED = 'Đỏ'


@dataclass(frozen=True)
class Detection:
    color: Color | None
    reason: str
    boxes: tuple[tuple[int, int, int, int, Color | None], ...] = ()


def read_image(path):
    frame = cv2.imdecode(np.fromfile(Path(path), dtype=np.uint8), cv2.IMREAD_COLOR)
    if frame is None:
        raise ValueError('Không đọc được ảnh.')
    return frame


class Classifier:
    def __init__(self, settings):
        self.roi = tuple(settings['roi'])
        if len(self.roi) != 4:
            raise ValueError('ROI cần bốn giá trị.')
        x1, y1, x2, y2 = self.roi
        if not (0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1):
            raise ValueError('ROI nằm ngoài ảnh.')
        self.delta = int(settings['background_delta'])
        self.black_max = int(settings['black_value_max'])
        self.min_area = float(settings['min_object_fraction'])
        if not 0 < self.delta < 255 or not 0 < self.black_max < 255:
            raise ValueError('Ngưỡng ảnh phải nằm trong khoảng 1–254.')
        if not 0 < self.min_area < 0.30:
            raise ValueError('Diện tích phôi tối thiểu phải nhỏ hơn 30% ROI.')

    def bounds(self, frame):
        h, w = frame.shape[:2]
        left, top, right, bottom = self.roi
        return round(w * left), round(h * top), round(w * right), round(h * bottom)

    def classify(self, frame, background):
        if background is not None and frame.shape != background.shape:
            return Detection(None, 'Hãy chụp lại nền ở độ phân giải hiện tại.')

        x, y, right, bottom = self.bounds(frame)
        roi = frame[y:bottom, x:right]
        if roi.size == 0:
            return Detection(None, 'ROI quá nhỏ.')
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        hue, saturation, value = cv2.split(hsv)
        red = ((hue <= 13) | (hue >= 164)) & (saturation >= 125) & (value >= 65)
        # The black workpiece has a blue cast in shadows. Require both chroma and light.
        blue = (hue >= 93) & (hue <= 136) & (saturation >= 125) & (value >= 75)
        black = (value <= self.black_max) & ((saturation <= 125) | (value <= 35))

        if background is None:
            # Preview of isolated objects against a light background only.
            foreground = red | blue | black
        else:
            base = background[y:bottom, x:right]
            current_lab = cv2.cvtColor(cv2.GaussianBlur(roi, (5, 5), 0), cv2.COLOR_BGR2LAB)
            base_lab = cv2.cvtColor(cv2.GaussianBlur(base, (5, 5), 0), cv2.COLOR_BGR2LAB)
            diff = cv2.absdiff(current_lab, base_lab)
            light, a, b = cv2.split(diff)
            foreground = (light >= self.delta) | (a >= self.delta) | (b >= self.delta)

        mask = foreground.astype(np.uint8) * 255
        side = max(3, round(min(roi.shape[:2]) * 0.018) | 1)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (side, side))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        area = roi.shape[0] * roi.shape[1]
        boxes = []
        clipped = False
        for contour in contours:
            if cv2.contourArea(contour) < area * self.min_area:
                continue
            bx, by, bw, bh = cv2.boundingRect(contour)
            if bx == 0 or by == 0 or bx + bw == roi.shape[1] or by + bh == roi.shape[0]:
                clipped = True
            filled = np.zeros(mask.shape, np.uint8)
            cv2.drawContours(filled, [contour], -1, 1, cv2.FILLED)
            inside = filled.astype(bool)
            count = int(inside.sum())
            red_share = float(red[inside].sum()) / count
            blue_share = float(blue[inside].sum()) / count
            if red_share >= 0.28 and blue_share <= 0.10:
                color = Color.RED
            elif blue_share >= 0.28 and red_share <= 0.10:
                color = Color.BLUE
            elif max(red_share, blue_share) <= 0.10 and float(black[inside].sum()) / count >= 0.65:
                color = Color.BLACK
            else:
                color = None
            boxes.append((x + bx, y + by, bw, bh, color))

        boxes.sort(key=lambda box: box[0])
        if not boxes:
            return Detection(None, 'Không thấy phôi đủ tương phản.')
        if len(boxes) != 1:
            return Detection(None, 'ROI có nhiều vật.', tuple(boxes))
        if clipped:
            return Detection(None, 'Phôi chạm mép ROI.', tuple(boxes))
        color = boxes[0][4]
        return Detection(color, color.value if color else 'Không xác định được màu.', tuple(boxes))

    def annotate(self, frame, detection):
        image = frame.copy()
        x, y, r, b = self.bounds(frame)
        cv2.rectangle(image, (x, y), (r - 1, b - 1), (105, 235, 255), 2)
        for dx, dy, w, h, color in detection.boxes:
            label = color.name if color else 'UNKNOWN'
            cv2.rectangle(image, (dx, dy), (dx + w, dy + h), (20, 190, 40), 2)
            cv2.putText(image, label, (dx, max(16, dy - 5)), cv2.FONT_HERSHEY_SIMPLEX,
                        0.65, (20, 190, 40), 2, cv2.LINE_AA)
        return image


class Camera:
    def __init__(self, settings):
        self.settings = settings
        self._lock = Lock()
        self._stop = Event()
        self._latest = None
        self.name = ''
        self.error = ''
        self._thread = Thread(target=self._capture, daemon=True)

    def start(self):
        self._thread.start()

    def close(self):
        self._stop.set()

    def is_alive(self):
        return self._thread.is_alive()

    def latest(self):
        with self._lock:
            return self._latest

    def _capture(self):
        capture = None
        try:
            device = find_camera(self.settings['camera_name'])
            self.name = device.name
            capture = cv2.VideoCapture(device.index, device.backend)
            if not capture.isOpened():
                raise OSError('Không mở được camera. Kiểm tra ứng dụng Camera đang dùng thiết bị.')
            capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.settings['camera_width'])
            capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.settings['camera_height'])
            while not self._stop.is_set():
                valid, frame = capture.read()
                if not valid:
                    raise OSError('Camera ngừng gửi hình.')
                with self._lock:
                    self._latest = (monotonic(), frame)
        except Exception as error:
            self.error = str(error)
        finally:
            if capture is not None:
                capture.release()


def list_cameras():
    return enumerate_cameras(cv2.CAP_DSHOW)


def find_camera(name):
    devices = [item for item in list_cameras() if name.casefold() in item.name.casefold()]
    if len(devices) != 1:
        raise ValueError(f'Cần đúng một camera khớp "{name}". Tìm được {len(devices)}.')
    return devices[0]
