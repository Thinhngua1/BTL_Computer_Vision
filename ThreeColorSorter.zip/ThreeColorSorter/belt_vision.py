from dataclasses import dataclass
from itertools import combinations

import cv2
import numpy as np

from vision import Classifier, Color, Detection


WIDTH, LENGTH = 168, 360
PLANE = np.float32([[0, 0], [WIDTH - 1, 0], [WIDTH - 1, LENGTH - 1], [0, LENGTH - 1]])


def side_rear(frame, columns, near_edge):
    height, width = frame.shape[:2]
    span = width - 1
    fractions = columns / span
    front = near_edge[0] + (near_edge[1] - near_edge[0]) * fractions
    lab = cv2.cvtColor(cv2.GaussianBlur(frame, (5, 5), 0), cv2.COLOR_BGR2LAB).astype(np.float32)
    floor_rows = np.rint(front - height * np.array([.035, .046, .057])[:, None]).astype(int)
    floor = np.median(lab[np.clip(floor_rows, 0, height - 1), columns], axis=0)
    separation = np.arange(round(height * .025), round(height * .23))
    rows = np.rint(front - separation[:, None]).astype(int)
    above = lab[np.clip(rows - 4, 0, height - 1), columns]
    below = lab[np.clip(rows + 4, 0, height - 1), columns]
    above_delta = np.linalg.norm(above - floor, axis=2)
    below_delta = np.linalg.norm(below - floor, axis=2)
    edges = np.linalg.norm(below - above, axis=2)
    strength = np.clip(np.minimum(edges, above_delta - below_delta) - .4 * below_delta, 0, 58)
    # Fit the rear edge independently. A constant depth expands the mask into the
    # background on the end of the conveyor that is farther from the camera.
    changes = np.linspace(-height * .22, height * .22, 31)
    depths = separation[None, :, None] + changes[:, None, None] * (fractions - .5)
    indices = np.rint(depths).astype(int) - separation[0]
    local = np.maximum.reduce([np.roll(strength, ix, axis=0) for ix in (-2, -1, 0, 1, 2)])
    points = local[np.clip(indices, 0, len(separation) - 1), np.arange(len(columns))]
    visible = (depths >= separation[0] + 2) & (depths <= separation[-1] - 2)
    scores = np.where(visible, points, 0)
    left = (scores[..., fractions < .5] >= 12).mean(axis=2)
    right = (scores[..., fractions >= .5] >= 12).mean(axis=2)
    quality = np.where(np.minimum(left, right) >= .22, scores.mean(axis=2), 0)
    slope, offset = np.unravel_index(np.argmax(quality), quality.shape)
    if quality[slope, offset] < 9:
        return np.maximum(0, near_edge - height * .083)
    best_depth = separation[offset] + changes[slope] * np.array([-.5, .5])
    return np.maximum(0, near_edge - np.clip(best_depth, separation[0], separation[-1]))


def side_rail(frame):
    height, width = frame.shape[:2]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    saturation = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)[:, :, 1]
    edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 0), 28, 83)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 360, 28,
                            minLineLength=round(width * .14), maxLineGap=round(width * .047))
    if lines is None:
        return None
    columns = np.arange(round(width * .04), round(width * .96), max(4, width // 54))
    offsets = np.maximum(1, np.round(np.array([.008, .014, .025, .033]) * height)).astype(int)
    candidates = []
    for x1, y1, x2, y2 in lines[:, 0]:
        if abs(x2 - x1) < width * .14:
            continue
        slope = (y2 - y1) / (x2 - x1)
        origin = y1 - slope * x1
        center = origin + slope * width * .5
        if abs(slope) > .38 or not height * .29 < center < height * .89:
            continue
        rows = np.rint(slope * columns + origin).astype(int)
        visible = (rows >= offsets[-1]) & (rows + offsets[-1] < height)
        if visible.mean() < .66:
            continue
        rows, visible_columns = rows[visible], columns[visible]
        below = rows + offsets[:, None]
        up = gray[rows - offsets[:, None], visible_columns].mean(axis=0)
        down = gray[below, visible_columns].mean(axis=0)
        contrast = down - up
        support = np.mean((contrast >= 18) & (saturation[below, visible_columns].mean(axis=0) < 64))
        if support >= .49 and np.median(down) > 94:
            score = float(np.median(contrast)) * support * visible.mean()
            candidates.append((score, slope, origin, center))
    # The guide rail is a dark-to-metal transition above a lower frame beam.
    pairs = []
    for score, slope, origin, center in candidates:
        if score >= 28 and any(
            lower_score > 12 and abs(lower_slope - slope) < .10
            and height * .075 < lower_center - center < height * .24
            for lower_score, lower_slope, _, lower_center in candidates
        ):
            pairs.append((score, slope, origin, center))
    if not pairs:
        return None
    strongest = max(pairs)
    # Prefer a distinct equally plausible edge above the beam, but treat nearby
    # fragments as the same edge and retain the strongest of those.
    upper = [line for line in pairs
             if line[0] > strongest[0] * .62 and line[3] < strongest[3] - height * .061]
    _, slope, origin, _ = max(upper, default=strongest)
    near_edge = origin + np.array([0, width - 1]) * slope
    far_edge = side_rear(frame, columns, near_edge)
    return np.float32([[0, far_edge[0]], [0, near_edge[0]],
                       [width - 1, near_edge[1]], [width - 1, far_edge[1]]])


def grounded_black_contours(black, belt_interior):
    width = black.shape[1]
    seeds, _ = cv2.findContours(black & belt_interior, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    bodies = []
    for seed in seeds:
        x, _, w, h = cv2.boundingRect(seed)
        if not width * .044 <= w <= width * .30 or h < 3:
            continue
        pad = max(2, round(w * .09))
        left, right = max(0, x - pad), min(width, x + w + pad)
        parts, _ = cv2.findContours(black[:, left:right].copy(), cv2.RETR_EXTERNAL,
                                    cv2.CHAIN_APPROX_SIMPLE, offset=(left, 0))
        bodies.extend(parts)
    return bodies


def side_parts(frame, outline, black_max):
    height, width = frame.shape[:2]
    columns = np.arange(width)
    rows = np.arange(height)[:, None]
    rear = np.linspace(outline[0, 1], outline[3, 1], width)
    front = np.linspace(outline[1, 1], outline[2, 1], width)
    hue, saturation, value = cv2.split(cv2.cvtColor(frame, cv2.COLOR_BGR2HSV))
    front_rows = np.clip(np.rint(front - height * .025).astype(int), 0, height - 1)
    belt_tone = float(np.median(value[front_rows, columns]))
    black_limit = min(black_max, max(43, belt_tone - 18))
    zone = (rows >= rear - height * .28) & (rows <= front - height * .009)
    margin = np.maximum(height * .012, (front - rear) * .13)
    belt_interior = (rows >= rear + margin).astype(np.uint8)
    masks = (
        (Color.BLACK, (value <= black_limit) & ((saturation <= 135) | (value <= 32))),
        (Color.BLUE, (hue >= 94) & (hue <= 134) & (saturation >= 111) & (value >= 68)),
        (Color.RED, ((hue <= 12) | (hue >= 164)) & (saturation >= 113) & (value >= 59)),
    )
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    black_size = max(5, round(width * .014) | 1)
    black_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (black_size, black_size))
    boxes = []
    for color, colors in masks:
        opening = black_kernel if color == Color.BLACK else kernel
        mask = cv2.morphologyEx((colors & zone).astype(np.uint8), cv2.MORPH_OPEN, opening)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        # Seed the dark body from its foot so a neighboring dark background
        # cannot merge into a single wide contour with the workpiece.
        if color == Color.BLACK:
            contours = grounded_black_contours(mask, belt_interior)
        else:
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            center = x + w // 2
            if not (width * .052 <= w <= width * .30 and height * .072 <= h <= height * .44):
                continue
            if not (.56 <= w / h <= 2.15 and cv2.contourArea(contour) >= w * h * .57):
                continue
            if x <= 1 or x + w >= width - 1 or y <= max(1, rear[center] - height * .27):
                continue
            support = np.arange(round(w * .20), round(w * .80))
            silhouette = np.zeros((h, w), np.uint8)
            cv2.drawContours(silhouette, [contour], -1, 1, cv2.FILLED, offset=(-x, -y))
            shape = silhouette[:, support]
            base = y + h - 1 - np.argmax(shape[::-1], axis=0)
            columns_at_base = x + support
            contact = (shape.any(axis=0) & (base >= rear[columns_at_base] + margin[columns_at_base])
                       & (base <= front[columns_at_base]))
            if contact.mean() < .70:
                continue
            boxes.append((x, y, w, h, color))
    return tuple(sorted(boxes))


def rail_outline(value):
    height, width = value.shape
    span = min(height, width)
    edges = cv2.Canny(cv2.GaussianBlur(value, (5, 5), 0), 45, 120)
    raw = cv2.HoughLinesP(edges, 1, np.pi / 180, 32,
                         minLineLength=int(span * .29), maxLineGap=int(span * .064))
    if raw is None:
        return None
    lines = raw[:, 0].reshape(-1, 2, 2).astype(np.float32)
    lengths = np.linalg.norm(lines[:, 1] - lines[:, 0], axis=1)
    selected = np.argsort(lengths)[-26:]
    best, best_score = None, 0.0
    for i, j in combinations(selected, 2):
        axis_a = (lines[i, 1] - lines[i, 0]) / lengths[i]
        axis_b = (lines[j, 1] - lines[j, 0]) / lengths[j]
        similarity = float(axis_a @ axis_b)
        if abs(similarity) < .963:
            continue
        axis = axis_a + axis_b * np.sign(similarity)
        axis /= np.linalg.norm(axis)
        a, b = lines[i], lines[j]
        positions_a, positions_b = a @ axis, b @ axis
        start = max(min(positions_a), min(positions_b))
        end = min(max(positions_a), max(positions_b))
        length = end - start
        if length < span * .34:
            continue
        def on_line(line, positions, target):
            return line[0] + (line[1] - line[0]) * ((target - positions[0]) / (positions[1] - positions[0]))

        a0, a1 = on_line(a, positions_a, start), on_line(a, positions_a, end)
        b0, b1 = on_line(b, positions_b, start), on_line(b, positions_b, end)
        gap = (np.linalg.norm(a0 - b0) + np.linalg.norm(a1 - b1)) * .5
        if not span * .13 < gap < span * .66 or length / gap < 1.5:
            continue
        rows = np.linspace(.10, .90, 10)[:, None, None]
        columns = np.array([-.14, -.07, .18, .32, .50, .68, .82, 1.07, 1.14])[None, :, None]
        left = a0 + (a1 - a0) * rows
        right = b0 + (b1 - b0) * rows
        sample = np.rint(left + (right - left) * columns).astype(int)
        x, y = sample[:, :, 0], sample[:, :, 1]
        levels = value[np.clip(y, 0, height - 1), np.clip(x, 0, width - 1)]
        middle = levels[:, 2:7]
        dark = float(np.median(middle))
        outer_left = float(np.median(levels[:, :2]))
        outer_right = float(np.median(levels[:, 7:]))
        contrast = min(outer_left, outer_right) - dark
        if dark > 107 or np.mean(middle < 125) < .77 or contrast < 13:
            continue
        score = length * gap * min(contrast, 80)
        if score > best_score:
            best_score = score
            best = np.float32([a0, b0, b1, a1])
    return best


def locate_belt(frame):
    height, width = frame.shape[:2]
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    value = hsv[:, :, 2]
    dark = (value <= 120).astype(np.uint8) * 255
    smoothed = cv2.morphologyEx(dark, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    smoothed = cv2.morphologyEx(smoothed, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    contours, _ = cv2.findContours(smoothed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best_score, best = 0.0, None
    for contour in contours:
        area = cv2.contourArea(contour)
        if not width * height * .045 <= area <= width * height * .78:
            continue
        _, sides, _ = cv2.minAreaRect(contour)
        if min(sides) < 24 or max(sides) / min(sides) < 1.6 or area < .65 * sides[0] * sides[1]:
            continue
        hull = cv2.convexHull(contour)
        length = cv2.arcLength(hull, True)
        corners = None
        for tolerance in (.012, .020, .030, .045, .060):
            polygon = cv2.approxPolyDP(hull, length * tolerance, True)
            if len(polygon) == 4:
                corners = polygon[:, 0].astype(np.float32)
                break
        if corners is None or cv2.contourArea(corners) < area * .75:
            continue
        mask = np.zeros((height, width), np.uint8)
        cv2.fillConvexPoly(mask, corners.astype(np.int32), 1)
        interior = cv2.erode(mask, np.ones((7, 7), np.uint8)).astype(bool)
        rim = (cv2.dilate(mask, np.ones((21, 21), np.uint8)) > mask)
        if not interior.any() or not rim.any():
            continue
        darkness = np.count_nonzero(dark[interior]) / np.count_nonzero(interior)
        contrast = float(np.median(value[rim])) - float(np.median(value[interior]))
        if darkness < .70 or contrast < 12:
            continue
        score = area * darkness * min(contrast, 55)
        if score > best_score:
            # Normalize the quad so the short side maps to the width of the belt.
            edges = np.linalg.norm(corners - np.roll(corners, -1, axis=0), axis=1)
            if edges[0] + edges[2] > edges[1] + edges[3]:
                corners = np.roll(corners, -1, axis=0)
            if tuple(corners[0] + corners[1]) > tuple(corners[2] + corners[3]):
                corners = np.roll(corners, -2, axis=0)
            best_score, best = score, corners
    return best if best is not None else rail_outline(value)


@dataclass(frozen=True)
class BeltResult:
    detection: Detection
    outline: tuple
    status: str
    at_station: Detection

    @property
    def ready(self):
        return self.status == 'locked'


class BeltVision:
    def __init__(self, settings):
        self.inside = Classifier({**settings, 'roi': [.048, .026, .952, .974],
                                  'min_object_fraction': .009})
        self.black_max = settings['black_value_max']
        self.reset()

    def reset(self):
        self.previous = None
        self.shape = None
        self.steady = 0
        self.seen = False
        self.side = False

    def update(self, frame):
        if self.shape != frame.shape:
            self.reset()
            self.shape = frame.shape
        quad = side_rail(frame)
        side = quad is not None
        if not side and not (self.seen and self.side):
            quad = locate_belt(frame)
        if quad is None:
            self.steady = 0
            self.previous = None
            status = 'lost' if self.seen else 'searching'
            reason = 'Mất dấu băng tải.' if self.seen else 'Đang tự tìm mặt băng tải.'
            unknown = Detection(None, reason)
            return BeltResult(unknown, (), status, unknown)
        span = min(frame.shape[:2])
        roll = None
        if self.previous is not None and self.side == side:
            roll = min((np.roll(quad, shift, axis=0) for shift in ((0,) if side else (0, 2))),
                       key=lambda item: np.linalg.norm(item - self.previous))
        if roll is not None and np.linalg.norm(roll - self.previous, axis=1).max() < span * .068:
            self.steady += 1
            quad = .55 * roll + .45 * self.previous
        else:
            self.steady = 1
        self.previous, self.side = quad, side
        outline = tuple((float(x), float(y)) for x, y in quad)
        if self.steady < 3:
            unknown = Detection(None, 'Đang xác nhận mặt băng.')
            return BeltResult(unknown, (), 'searching', unknown)
        self.seen = True
        if side:
            boxes = side_parts(frame, quad, self.black_max)
            station = tuple(box for box in boxes if .37 <= (box[0] + box[2] * .5) / frame.shape[1] <= .63)
            station_color = station[0][4] if len(station) == 1 else None
            color = boxes[0][4] if len(boxes) == 1 else None
            detection = Detection(color, color.value if color else
                                  ('Đã khoanh từng phôi trên băng.' if boxes else 'Chưa có phôi trên băng.'), boxes)
            target = Detection(station_color, station_color.value if station_color else
                               'Chưa có một phôi rõ màu tại vị trí chụp.', station)
            return BeltResult(detection, outline, 'locked', target)
        transform = cv2.getPerspectiveTransform(quad, PLANE)
        flat = cv2.warpPerspective(frame, transform, (WIDTH, LENGTH))
        # Side lanes estimate the local belt tone. Ignore the rails and the center path.
        lanes = np.concatenate((flat[:, 12:34], flat[:, WIDTH - 34:WIDTH - 12]), axis=1)
        tone = np.median(lanes, axis=1).astype(np.uint8)
        background = np.repeat(cv2.GaussianBlur(tone[:, None], (1, 19), 0), WIDTH, axis=1)
        candidate = self.inside.classify(flat, background)
        back = cv2.getPerspectiveTransform(PLANE, quad)
        boxes = []
        station = []
        for x, y, w, h, color in candidate.boxes:
            vertices = np.float32([[[x, y], [x + w, y], [x + w, y + h], [x, y + h]]])
            mapped = (*cv2.boundingRect(cv2.perspectiveTransform(vertices, back)), color)
            boxes.append(mapped)
            if .30 <= (y + h * .5) / LENGTH <= .70:
                inside = x > 9 and x + w < WIDTH - 9
                station.append((*mapped[:4], color if inside else None))
        detection = Detection(candidate.color, candidate.reason, tuple(boxes))
        station_color = station[0][4] if len(station) == 1 else None
        station_result = Detection(station_color, station_color.value if station_color else
                                   'Chưa có một phôi rõ màu tại vị trí chụp.', tuple(station))
        return BeltResult(detection, outline, 'locked', station_result)
