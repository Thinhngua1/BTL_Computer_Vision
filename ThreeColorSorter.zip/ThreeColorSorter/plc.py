from dataclasses import dataclass
from struct import pack
from time import monotonic, sleep

import serial

from vision import Color


# Zero-based coil addresses for the XD2 M area.
RUN = 0
HEARTBEAT = 2
BENCH = 6
RESULT = 10
STATUS = 20
INPUTS, OUTPUTS = 0x5000, 0x6000
MANUAL, MANUAL_VERSION, MANUAL_HOLD_VERSION = 46, 49, 50
LEGACY_COMMANDS = (RUN, RESULT, RESULT + 1)
SIGNATURE = (True, False, True, True, False, True)
RESULT_MASK = {Color.BLACK: 0b1001, Color.BLUE: 0b1010, Color.RED: 0b1100, None: 0b1000}


def with_crc(data):
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0xA001 if crc & 1 else 0)
    return data + pack('<H', crc)


@dataclass(frozen=True)
class Status:
    capture: bool
    busy: bool
    done: bool
    fault: bool


class OutputMismatch(Exception):
    def __init__(self, channel, outputs, stage, commands=None):
        states = ', '.join(f'Y{index} {"bật" if on else "tắt"}' for index, on in enumerate(outputs))
        message = f'Y{channel} không xác nhận đúng {stage}. PLC đọc {states}.'
        if commands is not None:
            bits = ', '.join(f'{name}={int(commands[name])}' for name in ('M0', 'M1', 'M10', 'M11'))
            message += f' Bit lệnh trước khi dừng ({bits}).'
        super().__init__(message)


class Plc:
    def __init__(self, link, station, baud, stop_bits=1, parity='E'):
        if not 1 <= station <= 247:
            raise ValueError('Địa chỉ PLC phải nằm trong khoảng 1–247.')
        self.link = link
        self.station = station
        self.gap = max(0.00175, 3.5 * (9 + stop_bits + (parity != 'N')) / baud)
        self.last_exchange = 0.0
        self.verified = False

    @classmethod
    def open_link(cls, port, settings):
        station = int(settings['plc_station'])
        if not 1 <= station <= 247:
            raise ValueError('Địa chỉ PLC phải nằm trong khoảng 1–247.')
        baud = int(settings['plc_baud'])
        stop_bits = settings['plc_stop_bits']
        parity = settings['plc_parity']
        link = serial.Serial(port, baud, parity=parity, stopbits=stop_bits,
                             timeout=0.22, write_timeout=0.22)
        try:
            return cls(link, station, baud, stop_bits, parity)
        except BaseException:
            link.close()
            raise

    @classmethod
    def open(cls, port, settings):
        plc = cls.open_link(port, settings)
        try:
            plc.status()
            return plc
        except BaseException:
            plc.close()
            raise

    def close(self):
        self.link.close()
        self.verified = False

    def _exchange(self, function, payload, response_size):
        remaining = self.gap - (monotonic() - self.last_exchange)
        if remaining > 0:
            sleep(remaining)
        try:
            self.link.reset_input_buffer()
            request = with_crc(bytes([self.station, function]) + payload)
            if self.link.write(request) != len(request):
                raise OSError('Gửi thiếu byte Modbus.')
            head = self.link.read(2)
            if len(head) != 2:
                raise TimeoutError('PLC không phản hồi. Kiểm tra cổng COM và cấu hình Modbus.')
            exception = head[1] == (function | 0x80)
            expected = 5 if exception else response_size
            response = head + self.link.read(expected - 2)
            if len(response) != expected or with_crc(response[:-2]) != response:
                raise OSError('Phản hồi Modbus thiếu byte hoặc sai CRC.')
            if head[0] != self.station or head[1] not in (function, function | 0x80):
                raise OSError('Sai địa chỉ hoặc mã hàm Modbus.')
            if exception:
                raise OSError(f'PLC trả mã lỗi Modbus 0x{response[2]:02X}.')
            return response[2:-2]
        finally:
            self.last_exchange = monotonic()

    def read_coils(self, start, count):
        size = (count + 7) // 8
        payload = self._exchange(1, pack('>HH', start, count), 5 + size)
        if payload[0] != size:
            raise OSError('Phản hồi Coil sai kích thước.')
        packed = int.from_bytes(payload[1:], 'little')
        return tuple(bool(packed & (1 << bit)) for bit in range(count))

    def status(self):
        bits = self.read_coils(STATUS, 10)
        self.verified = bits[4:] == SIGNATURE
        if not self.verified:
            raise ValueError('PLC phản hồi nhưng chương trình ThreeColorSorter chưa được xác nhận.')
        return Status(*bits[:4])

    def _write(self, start, count, value):
        if not self.verified:
            raise RuntimeError('Cần xác minh chương trình PLC trước khi ghi.')
        self._write_bits(start, count, value)

    def _write_bits(self, start, count, value):
        address_and_count = pack('>HH', start, count)
        payload = address_and_count + bytes([1, value])
        if self._exchange(15, payload, 8) != address_and_count:
            raise OSError('PLC trả sai địa chỉ hoặc số coil đã ghi.')

    def _write_coil(self, address, on):
        payload = pack('>HH', address, 0xFF00 if on else 0)
        if self._exchange(5, payload, 8) != payload:
            raise OSError(f'PLC trả sai xác nhận ghi M{address}.')

    def signals(self):
        commands = self.read_coils(RUN, 14)
        return {
            'inputs': self.read_coils(INPUTS, 4),
            'outputs': self.read_coils(OUTPUTS, 3),
            'commands': {f'M{index}': commands[index] for index in (0, 1, 10, 11, 12, 13)},
        }

    def manual_output(self, channel):
        if not self.read_coils(MANUAL_VERSION, 1)[0]:
            raise ValueError('Chương trình PLC này chưa hỗ trợ điều khiển tay.')
        if channel != 0 and not self.read_coils(MANUAL_HOLD_VERSION, 1)[0]:
            raise ValueError('Cần cập nhật chương trình PLC để giữ Y1 hoặc Y2.')
        state = self.status()
        if state.fault or state.busy or self.read_coils(RUN, 1)[0] or any(self.read_coils(OUTPUTS, 3)):
            raise ValueError('Dừng hệ thống, xoá lỗi và chờ ngõ ra tắt trước khi thử.')
        self._write(MANUAL, 3, 1 << channel)
        try:
            self._wait_output(channel)
        except (OSError, OutputMismatch):
            self.manual_stop()
            raise

    def manual_stop(self):
        self._write(MANUAL, 3, 0)
        self.expect_outputs_off()

    def expect_outputs_off(self):
        deadline = monotonic() + 0.65
        while any(self.read_coils(OUTPUTS, 3)):
            if monotonic() >= deadline:
                raise OSError('PLC vẫn báo ngõ ra bật. Kiểm tra thiết bị tại máy.')
            sleep(0.035)

    def legacy_stop(self):
        # Reference PLC.xdp has a global stop contact on M1 in all three rungs.
        self._write_coil(RUN + 1, True)
        for command in LEGACY_COMMANDS:
            self._write_coil(command, False)
        self.expect_outputs_off()

    def _wait_output(self, channel, *, conveyor_running=False):
        expected = tuple(index == channel or (index == 0 and conveyor_running) for index in range(3))
        deadline = monotonic() + 0.35
        while True:
            outputs = self.read_coils(OUTPUTS, 3)
            if outputs == expected:
                return
            if any(on and not allowed for on, allowed in zip(outputs, expected)) or monotonic() >= deadline:
                raise OutputMismatch(channel, outputs, 'khi gửi lệnh')
            sleep(0.035)

    def legacy_sort_relay(self, channel):
        if channel not in (1, 2):
            raise ValueError('Chọn đèn tín hiệu Y1 hoặc Y2.')
        try:
            outputs = self.read_coils(OUTPUTS, 3)
            if outputs not in ((True, False, False), (True, channel == 1, channel == 2)):
                raise OutputMismatch(0, outputs, 'trước khi bật đèn tín hiệu')
            self._write_coil(LEGACY_COMMANDS[channel], True)
            self._wait_output(channel, conveyor_running=True)
        except (OSError, OutputMismatch):
            self.legacy_stop()
            raise

    def legacy_release_sort_relay(self, channel):
        try:
            self._write_coil(LEGACY_COMMANDS[channel], False)
            deadline = monotonic() + 0.15
            while True:
                outputs = self.read_coils(OUTPUTS, 3)
                if outputs == (True, False, False):
                    return True
                if outputs != (True, channel == 1, channel == 2):
                    raise OutputMismatch(channel, outputs, 'khi nhả đèn tín hiệu')
                if monotonic() >= deadline:
                    return False
                sleep(0.035)
        except (OSError, OutputMismatch):
            self.legacy_stop()
            raise

    def legacy_release_with_belt_restart(self):
        # Reference holding contacts need M1. The caller has verified an empty belt.
        self.legacy_stop()
        self._legacy_enable(0, hold=True)

    def legacy_output(self, channel, *, hold=False):
        if any(self.read_coils(OUTPUTS, 3)):
            raise ValueError('Bấm Stop và chờ cả ba ngõ ra tắt trước khi chạy tay.')
        self.legacy_stop()
        self._legacy_enable(channel, hold=hold)

    def _legacy_enable(self, channel, *, hold):
        expected = tuple(index == channel for index in range(3))
        command = LEGACY_COMMANDS[channel]
        try:
            self._write_coil(RUN + 1, False)
            self._write_coil(command, True)
            self._wait_output(channel)
            if hold:
                return
            self._write_coil(command, False)
            sleep(0.10)
            outputs = self.read_coils(OUTPUTS, 3)
            if outputs != expected:
                raise OutputMismatch(channel, outputs, 'sau khi nhả bit lệnh')
        except (OSError, OutputMismatch):
            self.legacy_stop()
            raise

    def start(self):
        status = self.status()
        if status.fault or status.busy:
            raise ValueError('PLC đang bận hoặc có lỗi. Dừng và xoá lỗi trước khi chạy.')
        self.clear_result()
        self._write(RUN, 3, 0b101)

    def stop(self):
        self._write(RUN, 3, 0)
        self.clear_result()

    def reset(self):
        self.stop()
        self._write(RUN, 3, 0b010)
        try:
            deadline = monotonic() + 0.5
            while self.status().fault:
                if monotonic() >= deadline:
                    raise TimeoutError('PLC chưa xoá lỗi.')
                sleep(0.03)
        finally:
            self._write(RUN, 3, 0)

    def heartbeat(self, value):
        self._write(HEARTBEAT, 1, int(value))

    def bench_trigger(self):
        status = self.status()
        if status.busy or status.fault:
            raise ValueError('Chờ PLC hết bận và không có lỗi.')
        self._write(BENCH, 1, 1)

    def submit(self, color):
        self._write(RESULT, 4, RESULT_MASK[color])

    def clear_result(self):
        self._write(RESULT, 4, 0)
